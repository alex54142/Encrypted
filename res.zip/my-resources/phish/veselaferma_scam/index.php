<?php
header("Location: ./s1/");
?>
