var cloud = new Object;
var stats = 0;
var tour = 1;

var currentTime = new Date();  // to prevent caching
var n = currentTime.getTime();

// ************************************
// animationen ************************
// ************************************

function startAnimations()
{
	$('clouds1').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/clouds.png)';
	$('clouds2').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/clouds2.png)';
	$('sheepcloud').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/sheepclouds.png)';
	$('windmill').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/windmill.gif)';

	var isiPad = navigator.userAgent.match(/iPad/i) != null;  // beim ipad keine animationen
	if(isiPad) {  }
	else
	{
		moveCloud('clouds1',600);
		moveCloud('clouds2',250);
		initspeedsheep();
	}
}

function initspeedsheep()
{
	if(cloud['sheepcloud']) delete cloud['sheepcloud'];
	$('sheepcloud').style.left = (stats['width'] + 1000) + 'px';
	window.setTimeout("speedsheep()", 10000);
}

function speedsheep()
{
	if(!cloud['sheepcloud']) cloud['sheepcloud'] = new Effect.Move('sheepcloud', { x:-3500, y:0, duration:15, transition:Effect.Transitions.linear, mode:'relative', afterFinish:function(e) { initspeedsheep() } });
}

function moveCloud(id,dur)
{
	if(!cloud[id]) cloud[id] = new Effect.Move(id, { x:3500, y:0, duration:dur, transition:Effect.Transitions.linear, mode:'relative', afterFinish:function(e) { endCloud(id,dur) } });
}

function endCloud(id,dur)
{
	$(id).style.left = '-1284px';
	delete cloud[id];
	moveCloud(id,dur);
}

// ************************************
// screenanpassung ********************
// ************************************

function optimizeScreen(logout)
{
	stats = $('main').getDimensions();
	if(stats['height'] <= 800)
	{
		if(logout == 1) var width = 900;
		else var width = 800;
		$('main').style.height = width + 'px';
		$('content').style.height = width + 'px';
	}
	else
	{
		$('main').style.height = stats['height'] + 'px';
		if(stats['height'] <= 1050) $('content').style.height = stats['height'] + 'px';
		else $('content').style.height = '1050px';
	}
}

// ************************************
// tour *******************************
// ************************************

function scrollTour(dir)
{
	if(dir == 1) tour++;
	else tour--;
	if(tour < 1) tour = 7;
	else if(tour > 7) tour = 1;
	$('tourimg').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/tour/' + tour + '.jpg)';
	$('tourtxt').innerHTML = tourtxt[tour];
}

// ************************************
// login ******************************
// ************************************


// ************************************
// register ***************************
// ************************************

function startRegister()
{
	if($('registerusername').value == '') $('registerusername').focus();
	else if($('registerpassword').value == '') $('registerpassword').focus();
	else if($('registeremail').value == '') $('registeremail').focus();
	else if(!$('registerterms').checked) setBox('error',errorterms);

	if($('registerusername').value != '' && $('registerpassword').value != '' && $('registeremail').value != '' && $('registerterms').checked)
	{
		closeBox();
		load();
		new Ajax.Request('ajax/register2.php', {
			method:'post',
			parameters: { server:$('registerserver').value, username:$('registerusername').value, password:$('registerpassword').value, email:$('registeremail').value, ref:$('registerref').value, wid:$('registerwid').value, ef_id:$('registeref_id').value, retid:$('registerretid').value, token:$('registertoken').value, plsid:$('registerplsid').value, mk:$('registermk').value, mp:$('registermp').value, mt:$('registermt').value, mc:$('registermc').value, mn:$('registermn').value },
			onSuccess: function(transport) {
				load(1);
				var result = transport.responseText.evalJSON();
				if(result[0] == 0)
				{
					setBox('register');
					setBox('error',result[1]);
				}
				else if(result[1]) { location.href = result[1]; }
			}
		});
	}
	return false;
}

// ************************************
// sendpassword ***********************
// ************************************

function sendPassword()
{
	if($('forgottenemail').value == '') $('forgottenemail').focus();

	if($('forgottenemail').value != '')
	{
		closeBox('error');
		load();
		new Ajax.Request('ajax/sendpassword.php', {
			method:'post',
			parameters: { server:$('forgottenserver').value, email:$('forgottenemail').value },
			onSuccess: function(transport) {
				load(1);
				var result = transport.responseText.evalJSON();
				if(result[0] == 0) setBox('error',result[1]);
				else if(result[1]) $('pwforgottensuccess').style.display = 'block';
			}
		});
	}
	return false;
}

// ************************************
// portal *****************************
// ************************************

function portalLogin()
{
	var test = 0;
	closeBox('error');
	load();
	new Ajax.Request('ajax/portallogin.php?n=' + n, {
		method:'post',
		parameters: { server:$('portalserver').value, username:$('portalusername').value, password:$('portalpassword').value },
		onSuccess: function(transport) {
			load(1);
			var result = transport.responseText.evalJSON();
			if(result[0] == 0) setBox('error',result[1]);
			else if(result[1]) { location.href = result[1]; }
		}
	});
	return false;
}

// ************************************
// load *******************************
// ************************************

function load(close)
{
	if(!close)
	{
		$('load').style.display = 'block';
		$('block').style.display = 'block';
	}
	else
	{
		$('load').style.display = 'none';
		$('block').style.display = 'none';
	}
}

// ************************************
// boxes ******************************
// ************************************

var boxes = { "register":1,"logout":1,"tour":1,"spot":1,"infobox":1,"error":1,"pwforgotten":1,"registerpartner":1,"portal":1 };

function setBox(id,sub)
{
	if(boxes[id])
	{
		for(var i in boxes)
		{
			if($(i))
			{
				if(id == 'error' && (i == 'register' || i == 'pwforgotten' || i == 'portal')) { }  // formboxen bei fehler nicht autom. schlieГџen
				else $(i).style.display = 'none';
			}
		}
		$(id).style.display = 'block';

		if(id == 'logout') $('logoutiframe').src = 'adds/logoutad.php?ref=' + $('loginref').value;
		if(id == 'spot') $('spotiframe').src = 'https://www.youtube.com/embed/vZZi5hVltaw';
		if(id == 'error') $('errormessage').innerHTML = sub;
		if(id == 'pwforgotten') $('pwforgottensuccess').style.display = 'none';
		if(id == 'tour')
		{
			$('tourimg').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/tour/1.jpg)';
			$('tour').style.backgroundImage = 'url(https://mff.wavecdn.net/mff_start/img/tour_back.jpg)';
			$('tourtxt').innerHTML = tourtxt[1];
		}
		if(id == 'infobox')
		{
			$('about').style.display = 'none';
			$('story').style.display = 'none';
			$('features').style.display = 'none';
			$('rules').style.display = 'none';
			if($(sub)) $(sub).style.display = 'block';
		}
	}
}

function closeBox(id)
{
	if(!id)
	{
		for(var i in boxes)
		{
			if($(i)) $(i).style.display = 'none';
		}
	}
	else
	{
		$(id).style.display = 'none';
		if(id == 'logout') $('logoutiframe').src = '';
		if(id == 'error') $('errormessage').innerHTML = '';
		if(id == 'spot') $('spotiframe').src = '';
	}
}
